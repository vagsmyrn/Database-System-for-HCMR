--
-- Database : ELKETHE_DB
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `ALBmeasure`
--
DROP TABLE  IF EXISTS `ALBmeasure`;
CREATE TABLE `ALBmeasure` (
  `ALB_measure_ID` int(11) NOT NULL,
  `fl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `rw` double DEFAULT NULL,
  `sex` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `matur_stage` int(11) DEFAULT NULL,
  `gon_wei` double DEFAULT NULL,
  `lIfe_status` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `bait_type` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `commercial` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ALB_measure_ID`),
  UNIQUE KEY `ALB_measure_ID_UNIQUE` (`ALB_measure_ID`),
  CONSTRAINT `measure_ID` FOREIGN KEY (`ALB_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;



--
-- Tabel structure for table `BFTmeasure`
--
DROP TABLE  IF EXISTS `BFTmeasure`;
CREATE TABLE `BFTmeasure` (
  `BFT_measure_ID` int(11) NOT NULL,
  `fl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `rw` double DEFAULT NULL,
  `sex` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `pfl` double DEFAULT NULL,
  `matur_stage` int(11) DEFAULT NULL,
  `gon_wei` double DEFAULT NULL,
  `life_status` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `bait_type` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `commercial` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`BFT_measure_ID`),
  CONSTRAINT `BFT_measure_ID` FOREIGN KEY (`BFT_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;



--
-- Tabel structure for table `OTHERmeasure`
--
DROP TABLE  IF EXISTS `OTHERmeasure`;
CREATE TABLE `OTHERmeasure` (
  `OTHER_measure_ID` int(11) NOT NULL,
  `species_name` varchar(45) DEFAULT 'UNKNOWN',
  `common_name` varchar(45) DEFAULT 'UNKNOWN',
  `fl` double DEFAULT NULL,
  `tl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `rw` double DEFAULT NULL,
  `sex` varchar(45) DEFAULT 'UNKNOWN',
  `life_status` varchar(45) DEFAULT 'UNKNOWN',
  `bait_type` varchar(45) DEFAULT 'UNKNOWN',
  `commercial` varchar(45) DEFAULT 'UNKNOWN',
  PRIMARY KEY (`OTHER_measure_ID`),
  UNIQUE KEY `OTHER_measure_ID_UNIQUE` (`OTHER_measure_ID`),
  CONSTRAINT `OTHER_measure_ID` FOREIGN KEY (`OTHER_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;



--
-- Tabel structure for table `RVTmeasure`
--
DROP TABLE  IF EXISTS `RVTmeasure`;
CREATE TABLE `RVTmeasure` (
  `RVT_measure_ID` int(11) NOT NULL,
  `fl` double DEFAULT NULL,
  `tl` double DEFAULT NULL,
  `pffl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `rw` double DEFAULT NULL,
  `sex` varchar(45) DEFAULT 'UNKNOWN',
  `life_status` varchar(45) DEFAULT 'UNKNOWN',
  `bait_type` varchar(45) DEFAULT 'UNKNOWN',
  `commercial` varchar(45) DEFAULT 'UNKNOWN',
  PRIMARY KEY (`RVT_measure_ID`),
  UNIQUE KEY `RVT_measure_ID_UNIQUE` (`RVT_measure_ID`),
  CONSTRAINT `RVT_measure_ID` FOREIGN KEY (`RVT_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;



--
-- Tabel structure for table `SWOmeasure`
--
DROP TABLE  IF EXISTS `SWOmeasure`;
CREATE TABLE `SWOmeasure` (
  `SWO_measure_ID` int(11) NOT NULL,
  `ljfl` double DEFAULT NULL,
  `gg` double DEFAULT NULL,
  `sex` varchar(45) DEFAULT 'UNKNOWN',
  `rw` double DEFAULT NULL,
  `dw` double DEFAULT NULL,
  `pfl` double DEFAULT NULL,
  `head_length` double DEFAULT NULL,
  `matur_stage` int(11) DEFAULT NULL,
  `gon_wei` double DEFAULT NULL,
  `parasites` varchar(45) DEFAULT 'UNKNOWN',
  `life_status` varchar(45) DEFAULT 'UNKNOWN',
  `bait_type` varchar(45) DEFAULT 'UNKNOWN',
  `commercial` varchar(45) DEFAULT 'UNKNOWN',
  PRIMARY KEY (`SWO_measure_ID`),
  CONSTRAINT `SWO_measure_ID` FOREIGN KEY (`SWO_measure_ID`) REFERENCES `species_measurements` (`measure_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;



--
-- Tabel structure for table `dynamic_vessel`
--
DROP TABLE  IF EXISTS `dynamic_vessel`;
CREATE TABLE `dynamic_vessel` (
  `vessel_production_ID` int(11) NOT NULL,
  `Winch_type` varchar(45) DEFAULT NULL,
  `year` int(11) NOT NULL,
  `float_distance` varchar(45) DEFAULT NULL,
  `branch_line_distance` varchar(45) DEFAULT NULL,
  `ml_diameter` int(10) unsigned zerofill DEFAULT NULL,
  `bl_diameter` int(10) unsigned zerofill DEFAULT NULL,
  `bl_legnth` int(10) unsigned zerofill DEFAULT NULL,
  `float_length` int(10) unsigned zerofill DEFAULT NULL,
  `hooks_set` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `hooks_no` int(11) unsigned zerofill DEFAULT NULL,
  `extra_comments` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`vessel_production_ID`),
  UNIQUE KEY `vessel_production_ID_UNIQUE` (`vessel_production_ID`),
  CONSTRAINT `dvessel_ID` FOREIGN KEY (`vessel_production_ID`) REFERENCES `dynamic_vessel_ID` (`dynamic_vessel_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;



--
-- Tabel structure for table `dynamic_vessel_ID`
--
DROP TABLE  IF EXISTS `dynamic_vessel_ID`;
CREATE TABLE `dynamic_vessel_ID` (
  `AMAS` varchar(45) CHARACTER SET greek NOT NULL,
  `dynamic_vessel_ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`dynamic_vessel_ID`),
  KEY `AMAS_idx` (`AMAS`),
  CONSTRAINT `V_AMAS` FOREIGN KEY (`AMAS`) REFERENCES `vessel` (`AMAS`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `expedition`
--
DROP TABLE  IF EXISTS `expedition`;
CREATE TABLE `expedition` (
  `expedition_ID` int(11) NOT NULL AUTO_INCREMENT,
  `deployDate` date DEFAULT NULL,
  `returnDate` date DEFAULT NULL,
  `Hooks_day` varchar(45) DEFAULT 'UNKNOWN',
  `FishingDays` int(11) DEFAULT NULL,
  `Effort` int(11) DEFAULT NULL,
  `Gear` varchar(45) DEFAULT 'UNKNOWN',
  `Detail_Area` varchar(150) DEFAULT 'UNKNOWN',
  `StartSettingTime` time DEFAULT NULL,
  `StartLat` varchar(45) DEFAULT 'UNKNOWN',
  `StartLON` varchar(45) DEFAULT NULL,
  `EndSetTime` time DEFAULT NULL,
  `EndLAT` varchar(45) DEFAULT 'UNKNOWN',
  `EndLON` varchar(45) DEFAULT 'UNKNOWN',
  `StartHaulTime` time DEFAULT NULL,
  `StartLATHaul` varchar(45) DEFAULT 'UNKNOWN',
  `StartLONHaul` varchar(45) DEFAULT 'UNKNOWN',
  `EndHaulTime` time DEFAULT NULL,
  `EndLATHaul` varchar(45) DEFAULT 'UNKNOWN',
  `EndLONHaul` varchar(45) DEFAULT 'UNKNOWN',
  `Lightsticks` tinyint(1) DEFAULT NULL,
  `InfoOrigin` varchar(45) DEFAULT 'UNKNOWN',
  `Comments` varchar(200) DEFAULT 'UNKNOWN',
  PRIMARY KEY (`expedition_ID`),
  UNIQUE KEY `expedition_ID` (`expedition_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=greek;



--
-- Tabel structure for table `expedition_size`
--
DROP TABLE  IF EXISTS `expedition_size`;
CREATE TABLE `expedition_size` (
  `weight` double DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `species` varchar(45) NOT NULL,
  `size_expedition_ID` int(11) NOT NULL,
  PRIMARY KEY (`species`,`size_expedition_ID`),
  KEY `expedition_ID_idx` (`size_expedition_ID`),
  CONSTRAINT `size_expedition_ID` FOREIGN KEY (`size_expedition_ID`) REFERENCES `vessel_expeditions` (`expedition_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;



--
-- Tabel structure for table `gears`
--
DROP TABLE  IF EXISTS `gears`;
CREATE TABLE `gears` (
  `name` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `gears`  VALUES ( "Albacore longline","LAL");
INSERT INTO `gears`  VALUES ( "American longline","LLA");
INSERT INTO `gears`  VALUES ( "Bottom longline","BLL");
INSERT INTO `gears`  VALUES ( "Bottom trawl","BT");
INSERT INTO `gears`  VALUES ( "Classic longline","LLC");
INSERT INTO `gears`  VALUES ( "Diving","D");
INSERT INTO `gears`  VALUES ( "Handline","HL");
INSERT INTO `gears`  VALUES ( "Nets","N");
INSERT INTO `gears`  VALUES ( "Traps","TRP");
INSERT INTO `gears`  VALUES ( "Troll-line","TL");
INSERT INTO `gears`  VALUES ( "Unknown","UN");


--
-- Tabel structure for table `ports`
--
DROP TABLE  IF EXISTS `ports`;
CREATE TABLE `ports` (
  `name` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ports`  VALUES ( "?????????","ALO");
INSERT INTO `ports`  VALUES ( "?????","CRE");
INSERT INTO `ports`  VALUES ( "????????","CYC");
INSERT INTO `ports`  VALUES ( "?????????","HAL");
INSERT INTO `ports`  VALUES ( "?????","HAN");
INSERT INTO `ports`  VALUES ( "I????","ION");
INSERT INTO `ports`  VALUES ( "????????","KAL");
INSERT INTO `ports`  VALUES ( "?????","OTH");
INSERT INTO `ports`  VALUES ( "?????","PAT");


--
-- Tabel structure for table `production`
--
DROP TABLE  IF EXISTS `production`;
CREATE TABLE `production` (
  `production_ID` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `SWOproduction` int(11) unsigned zerofill DEFAULT NULL,
  `ALBproduction` int(11) unsigned zerofill DEFAULT NULL,
  `BFTproduction` int(11) unsigned zerofill DEFAULT NULL,
  `RVTproduction` int(11) unsigned zerofill DEFAULT NULL,
  `fishing_days` int(11) unsigned zerofill DEFAULT NULL,
  `wtc` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `bait` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`production_ID`),
  UNIQUE KEY `production_ID_UNIQUE` (`production_ID`),
  CONSTRAINT `production_ID` FOREIGN KEY (`production_ID`) REFERENCES `production_ID` (`production_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;

INSERT INTO `production`  VALUES ( "1","1991","00000014600","","","","","4","");
INSERT INTO `production`  VALUES ( "2","1991","00000007800","","","","","2","");
INSERT INTO `production`  VALUES ( "3","2001","00000005557","","00000000750","","","3","????????");
INSERT INTO `production`  VALUES ( "4","2003","","","","","","2","????????");
INSERT INTO `production`  VALUES ( "5","1991","00000035000","","","","","4","");
INSERT INTO `production`  VALUES ( "6","1994","00000012500","","00000012500","","","1","");
INSERT INTO `production`  VALUES ( "7","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "8","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "9","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "10","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "11","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "12","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "13","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "14","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "15","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "16","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "17","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "18","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "19","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "20","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "21","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "22","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "23","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "24","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "25","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "26","1989","","","","","","","");
INSERT INTO `production`  VALUES ( "27","1993","00000000325","","","","","1","");
INSERT INTO `production`  VALUES ( "28","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "29","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "30","2000","","","","","","","");
INSERT INTO `production`  VALUES ( "31","1994","","","","","","","");
INSERT INTO `production`  VALUES ( "32","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "33","1999","00000004200","","00000001200","","","2","????????");
INSERT INTO `production`  VALUES ( "34","2000","00000008000","","00000004050","","","3","");
INSERT INTO `production`  VALUES ( "35","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "36","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "37","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "38","1995","","","","","","1","");
INSERT INTO `production`  VALUES ( "39","1995","","","","","","","????????");
INSERT INTO `production`  VALUES ( "40","2003","","","","","","4","");
INSERT INTO `production`  VALUES ( "41","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "42","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "43","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "44","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "45","2002","00000002000","","00000000000","","","4","");
INSERT INTO `production`  VALUES ( "46","2003","","","","","","2","");
INSERT INTO `production`  VALUES ( "47","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "48","1995","","","","","","","????????-????????");
INSERT INTO `production`  VALUES ( "49","2004","","","","","","1","");
INSERT INTO `production`  VALUES ( "50","1995","","","","","","1","????????-????????");
INSERT INTO `production`  VALUES ( "51","1995","","","","","","2","????????-????????");
INSERT INTO `production`  VALUES ( "52","1995","","","","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "53","2000","","","","","","","");
INSERT INTO `production`  VALUES ( "54","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "55","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "56","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "57","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "58","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "59","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "60","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "61","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "62","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "63","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "64","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "65","1994","00000008600","","","","","4","");
INSERT INTO `production`  VALUES ( "66","2001","","","","","","","");
INSERT INTO `production`  VALUES ( "67","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "68","1995","","","","","","1","");
INSERT INTO `production`  VALUES ( "69","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "70","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "71","1999","00000003500","","00000001250","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "72","1995","","","","","","3","");
INSERT INTO `production`  VALUES ( "73","1987","","","","","","","");
INSERT INTO `production`  VALUES ( "74","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "75","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "76","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "77","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "78","2003","","","","","","1","");
INSERT INTO `production`  VALUES ( "79","2001","","","","","","","");
INSERT INTO `production`  VALUES ( "80","1995","","","","","","1","");
INSERT INTO `production`  VALUES ( "81","1998","00000004600","","00000000650","","","2","");
INSERT INTO `production`  VALUES ( "82","1999","","","","","","","");
INSERT INTO `production`  VALUES ( "83","1998","","","","","","","");
INSERT INTO `production`  VALUES ( "84","1999","","","","","","","");
INSERT INTO `production`  VALUES ( "85","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "86","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "87","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "88","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "89","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "90","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "91","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "92","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "93","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "94","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "95","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "96","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "97","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "98","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "99","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "100","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "101","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "102","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "103","1991","00000001000","","","","","2","");
INSERT INTO `production`  VALUES ( "104","1998","","","","","","","????????");
INSERT INTO `production`  VALUES ( "105","1999","","","","","","","????????");
INSERT INTO `production`  VALUES ( "106","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "107","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "108","2011","00000017270","","00000000400","","","4","");
INSERT INTO `production`  VALUES ( "109","1991","00000020785","","","","","4","");
INSERT INTO `production`  VALUES ( "110","1999","","","","","","2","????????-????????");
INSERT INTO `production`  VALUES ( "111","2003","","","","","","3","????????-????????");
INSERT INTO `production`  VALUES ( "112","1998","","","","","","","");
INSERT INTO `production`  VALUES ( "113","1999","","","","","","","");
INSERT INTO `production`  VALUES ( "114","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "115","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "116","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "117","1999","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "118","2001","","","","","","3","");
INSERT INTO `production`  VALUES ( "119","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "120","2009","","","","","","","skoubri");
INSERT INTO `production`  VALUES ( "121","1993","00000001500","","","","","","");
INSERT INTO `production`  VALUES ( "122","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "123","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "124","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "125","1999","","","","","","4","");
INSERT INTO `production`  VALUES ( "126","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "127","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "128","2005","","","","","","","????????, ???????");
INSERT INTO `production`  VALUES ( "129","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "130","2002","00000017487","","00000004400","","","4","");
INSERT INTO `production`  VALUES ( "131","2003","00000000501","","00000000000","","","2","");
INSERT INTO `production`  VALUES ( "132","1995","","","","","","","????????");
INSERT INTO `production`  VALUES ( "133","1991","00000022490","","","","","4","");
INSERT INTO `production`  VALUES ( "134","1998","","","","","","2","????????");
INSERT INTO `production`  VALUES ( "135","1999","","","","","","2","????????");
INSERT INTO `production`  VALUES ( "136","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "137","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "138","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "139","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "140","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "141","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "142","1999","","","","","","1","????????");
INSERT INTO `production`  VALUES ( "143","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "144","2003","00000001150","","","","","1","");
INSERT INTO `production`  VALUES ( "145","2006","","","","","","","???????-????????");
INSERT INTO `production`  VALUES ( "146","1994","00000001300","","","","","1","");
INSERT INTO `production`  VALUES ( "147","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "148","1998","","","","","","","????????");
INSERT INTO `production`  VALUES ( "149","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "150","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "151","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "152","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "153","1998","","","","","","","");
INSERT INTO `production`  VALUES ( "154","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "155","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "156","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "157","1998","","","","","","1","????????");
INSERT INTO `production`  VALUES ( "158","1991","00000013060","","","","","3","");
INSERT INTO `production`  VALUES ( "159","1999","","","","","","3","????????-????????");
INSERT INTO `production`  VALUES ( "160","2003","00000004858","","00000000000","","","2","????????-????????");
INSERT INTO `production`  VALUES ( "161","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "162","1991","00000015295","","","","","4","");
INSERT INTO `production`  VALUES ( "163","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "164","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "165","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "166","1991","00000007250","","","","","3","????????");
INSERT INTO `production`  VALUES ( "167","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "168","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "169","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "170","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "171","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "172","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "173","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "174","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "175","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "176","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "177","2001","","","","","","4","????????");
INSERT INTO `production`  VALUES ( "178","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "179","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "180","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "181","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "182","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "183","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "184","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "185","1995","","","","","","4","");
INSERT INTO `production`  VALUES ( "186","1999","00000012500","","00000001200","","","4","");
INSERT INTO `production`  VALUES ( "187","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "188","2001","","","","","","","");
INSERT INTO `production`  VALUES ( "189","1991","00000004670","","","","","3","");
INSERT INTO `production`  VALUES ( "190","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "191","1991","00000021650","","","","","4","");
INSERT INTO `production`  VALUES ( "192","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "193","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "194","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "195","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "196","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "197","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "198","1993","00000000125","","","","","1","");
INSERT INTO `production`  VALUES ( "199","1998","","","","","","1","????????");
INSERT INTO `production`  VALUES ( "200","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "201","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "202","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "203","1998","","","","","","2","");
INSERT INTO `production`  VALUES ( "204","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "205","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "206","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "207","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "208","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "209","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "210","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "211","1998","","","","","","","");
INSERT INTO `production`  VALUES ( "212","2005","","","","","","","????????");
INSERT INTO `production`  VALUES ( "213","2009","","","","","","","");
INSERT INTO `production`  VALUES ( "214","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "215","1999","","","","","","1","");
INSERT INTO `production`  VALUES ( "216","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "217","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "218","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "219","1993","00000005845","","","","","2","");
INSERT INTO `production`  VALUES ( "220","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "221","1994","00000009200","","00000002150","","","4","");
INSERT INTO `production`  VALUES ( "222","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "223","1999","","","","","","4","????????");
INSERT INTO `production`  VALUES ( "224","2001","","","","","","4","????????");
INSERT INTO `production`  VALUES ( "225","1995","","","","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "226","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "227","1998","","","","","","","");
INSERT INTO `production`  VALUES ( "228","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "229","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "230","1998","","","","","","1","");
INSERT INTO `production`  VALUES ( "231","1995","","","","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "232","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "233","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "234","1994","","","","","","","");
INSERT INTO `production`  VALUES ( "235","1999","00000006200","","00000002100","","","3","????????-????????");
INSERT INTO `production`  VALUES ( "236","2003","00000006900","","00000000660","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "237","1999","","","","","","4","????????");
INSERT INTO `production`  VALUES ( "238","2003","00000012101","","00000002081","","","3","????????-????????");
INSERT INTO `production`  VALUES ( "239","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "240","1994","00000023700","","","","","4","");
INSERT INTO `production`  VALUES ( "241","2004","00000001500","","00000000450","","","2","????????");
INSERT INTO `production`  VALUES ( "242","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "243","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "244","1993","00000003500","","","","","","");
INSERT INTO `production`  VALUES ( "245","2002","00000003500","","00000000080","","","3","");
INSERT INTO `production`  VALUES ( "246","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "247","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "248","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "249","1991","00000003100","","","","","1","");
INSERT INTO `production`  VALUES ( "250","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "251","1986","","","","","","","");
INSERT INTO `production`  VALUES ( "252","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "253","2001","","","","","","1","");
INSERT INTO `production`  VALUES ( "254","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "255","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "256","2000","","","","","","","");
INSERT INTO `production`  VALUES ( "257","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "258","1995","","","","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "259","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "260","1995","","","","","","1","");
INSERT INTO `production`  VALUES ( "261","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "262","1999","00000014000","","00000007100","","","3","????????-????????");
INSERT INTO `production`  VALUES ( "263","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "264","1991","00000011000","","","","","4","");
INSERT INTO `production`  VALUES ( "265","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "266","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "267","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "268","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "269","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "270","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "271","2009","","","","","","","????????+????????");
INSERT INTO `production`  VALUES ( "272","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "273","1998","","","","","","1","");
INSERT INTO `production`  VALUES ( "274","2008","","","","","","","");
INSERT INTO `production`  VALUES ( "275","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "276","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "277","1991","00000001800","","","","","1","");
INSERT INTO `production`  VALUES ( "278","1998","","","","","","","");
INSERT INTO `production`  VALUES ( "279","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "280","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "281","1995","","","","","","4","????????");
INSERT INTO `production`  VALUES ( "282","2005","","","","","","","??????, ??????");
INSERT INTO `production`  VALUES ( "283","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "284","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "285","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "286","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "287","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "288","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "289","2007","00000017500","","00000000540","","","4","");
INSERT INTO `production`  VALUES ( "290","1995","","","","","","3","");
INSERT INTO `production`  VALUES ( "291","1999","","","","","","3","");
INSERT INTO `production`  VALUES ( "292","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "293","2001","","","","","","3","");
INSERT INTO `production`  VALUES ( "294","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "295","1995","","","","","","","");
INSERT INTO `production`  VALUES ( "296","1998","","","","","","2","????????");
INSERT INTO `production`  VALUES ( "297","2000","00000001730","","00000000010","","","2","????????-????????");
INSERT INTO `production`  VALUES ( "298","2004","00000019584","","00000002432","","","4","");
INSERT INTO `production`  VALUES ( "299","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "300","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "301","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "302","1993","00000002500","","","","","","");
INSERT INTO `production`  VALUES ( "303","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "304","2005","","","","","","","");
INSERT INTO `production`  VALUES ( "305","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "306","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "307","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "308","1993","00000000190","","","","","1","");
INSERT INTO `production`  VALUES ( "309","1999","","","","","","1","????????");
INSERT INTO `production`  VALUES ( "310","2001","00000015000","","","","","1","????????");
INSERT INTO `production`  VALUES ( "311","1995","","","","","","4","");
INSERT INTO `production`  VALUES ( "312","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "313","1991","00000008030","","","","","2","");
INSERT INTO `production`  VALUES ( "314","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "315","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "316","1995","","","","","","3","????????-????????");
INSERT INTO `production`  VALUES ( "317","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "318","1999","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "319","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "320","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "321","1999","","","","","","1","");
INSERT INTO `production`  VALUES ( "322","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "323","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "324","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "325","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "326","2003","00000003860","","","","","1","");
INSERT INTO `production`  VALUES ( "327","1995","","","","","","1","");
INSERT INTO `production`  VALUES ( "328","2001","","","","","","1","");
INSERT INTO `production`  VALUES ( "329","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "330","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "331","1999","00000013200","","00000001250","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "332","1999","00000012500","","00000001150","","","4","????????");
INSERT INTO `production`  VALUES ( "333","2002","00000004400","","00000000270","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "334","2003","00000005180","","00000000000","","","2","????????-????????");
INSERT INTO `production`  VALUES ( "335","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "336","2000","","","","","","","");
INSERT INTO `production`  VALUES ( "337","1999","00000005500","","00000003700","","","4","");
INSERT INTO `production`  VALUES ( "338","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "339","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "340","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "341","1995","","","","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "342","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "343","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "344","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "345","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "346","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "347","1994","","","","","","","");
INSERT INTO `production`  VALUES ( "348","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "349","1994","","","","","","","");
INSERT INTO `production`  VALUES ( "350","1994","","","","","","","");
INSERT INTO `production`  VALUES ( "351","1993","00000002395","","","","","2","");
INSERT INTO `production`  VALUES ( "352","1993","00000000250","","","","","1","");
INSERT INTO `production`  VALUES ( "353","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "354","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "355","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "356","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "357","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "358","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "359","1995","","","","","","1","????????-????????");
INSERT INTO `production`  VALUES ( "360","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "361","2001","00000002630","","00000000000","","","1","");
INSERT INTO `production`  VALUES ( "362","1995","","","","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "363","2000","00000002600","","00000000450","","","2","????????-????????");
INSERT INTO `production`  VALUES ( "364","1998","","","","","","1","");
INSERT INTO `production`  VALUES ( "365","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "366","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "367","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "368","2001","","","","","","","");
INSERT INTO `production`  VALUES ( "369","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "370","1995","","","","","","1","????????-????????");
INSERT INTO `production`  VALUES ( "371","2002","","","","","","4","");
INSERT INTO `production`  VALUES ( "372","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "373","1994","00000007000","","","","","2","");
INSERT INTO `production`  VALUES ( "374","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "375","2001","","","","","","1","");
INSERT INTO `production`  VALUES ( "376","1995","","","","","","4","????????");
INSERT INTO `production`  VALUES ( "377","2003","00000016800","","00000004050","","","4","????????");
INSERT INTO `production`  VALUES ( "378","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "379","1987","","","","","","","????????");
INSERT INTO `production`  VALUES ( "380","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "381","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "382","2001","00000009200","","00000000503","","","4","");
INSERT INTO `production`  VALUES ( "383","2003","00000010359","","00000002880","","","3","");
INSERT INTO `production`  VALUES ( "384","1995","","","","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "385","1991","00000023740","","","","","4","");
INSERT INTO `production`  VALUES ( "386","2003","00000005700","","00000004500","","","3","????????-????????");
INSERT INTO `production`  VALUES ( "387","1999","00000011500","","00000001750","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "388","1991","00000005050","","","","","2","");
INSERT INTO `production`  VALUES ( "389","1991","00000019000","","","","","4","");
INSERT INTO `production`  VALUES ( "390","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "391","2001","","","","","","","");
INSERT INTO `production`  VALUES ( "392","2003","00000021500","","00000002650","","","4","");
INSERT INTO `production`  VALUES ( "393","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "394","2001","","","","","","1","");
INSERT INTO `production`  VALUES ( "395","1991","00000000500","","","","","1","");
INSERT INTO `production`  VALUES ( "396","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "397","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "398","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "399","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "400","2002","00000002000","","00000000000","","","1","");
INSERT INTO `production`  VALUES ( "401","2003","","","","","","2","");
INSERT INTO `production`  VALUES ( "402","1994","00000014000","","","","","","");
INSERT INTO `production`  VALUES ( "403","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "404","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "405","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "406","2001","","","","","","3","");
INSERT INTO `production`  VALUES ( "407","1999","","","","","","2","");
INSERT INTO `production`  VALUES ( "408","2003","","","","","","2","");
INSERT INTO `production`  VALUES ( "409","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "410","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "411","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "412","2004","","","","","","","");
INSERT INTO `production`  VALUES ( "413","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "414","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "415","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "416","2006","","","","","","","");
INSERT INTO `production`  VALUES ( "417","1998","","","","","","2","????????");
INSERT INTO `production`  VALUES ( "418","1995","","","","","","","????????");
INSERT INTO `production`  VALUES ( "419","1995","","","","","","4","????????-????????");
INSERT INTO `production`  VALUES ( "420","2003","00000004400","","00000000010","","","2","????????-????????");
INSERT INTO `production`  VALUES ( "421","1994","00000015000","","","","","4","");
INSERT INTO `production`  VALUES ( "422","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "423","1991","00000003960","","","","","1","");
INSERT INTO `production`  VALUES ( "424","1998","","","","","","3","????????");
INSERT INTO `production`  VALUES ( "425","2004","","","","","","3","???????, ????????");
INSERT INTO `production`  VALUES ( "426","2005","","","","","","","???????? ??? ????????");
INSERT INTO `production`  VALUES ( "427","1991","00000001750","","","","","1","");
INSERT INTO `production`  VALUES ( "428","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "429","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "430","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "431","1993","00000000700","","","","","1","");
INSERT INTO `production`  VALUES ( "432","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "433","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "434","1992","","","","","","","");
INSERT INTO `production`  VALUES ( "435","1998","","","","","","","");
INSERT INTO `production`  VALUES ( "436","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "437","1998","","","","","","","");
INSERT INTO `production`  VALUES ( "438","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "439","1991","","","","","","","");
INSERT INTO `production`  VALUES ( "440","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "441","1994","","","","","","","");
INSERT INTO `production`  VALUES ( "442","1991","00000009340","","","","","4","");
INSERT INTO `production`  VALUES ( "443","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "444","2003","","","","","","","");
INSERT INTO `production`  VALUES ( "445","0","00000000000","00000000000","00000000000","00000000000","00000000000","
  ","");


--
-- Tabel structure for table `production_ID`
--
DROP TABLE  IF EXISTS `production_ID`;
CREATE TABLE `production_ID` (
  `production_ID` int(11) NOT NULL AUTO_INCREMENT,
  `AMAS` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`production_ID`),
  UNIQUE KEY `production_ID_UNIQUE` (`production_ID`),
  KEY `AMAS_idx` (`AMAS`),
  CONSTRAINT `AMAS` FOREIGN KEY (`AMAS`) REFERENCES `vessel` (`AMAS`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=446 DEFAULT CHARSET=greek;

INSERT INTO `production_ID`  VALUES ( "1","");
INSERT INTO `production_ID`  VALUES ( "2","");
INSERT INTO `production_ID`  VALUES ( "3","");
INSERT INTO `production_ID`  VALUES ( "4","");
INSERT INTO `production_ID`  VALUES ( "5","");
INSERT INTO `production_ID`  VALUES ( "6","");
INSERT INTO `production_ID`  VALUES ( "7","");
INSERT INTO `production_ID`  VALUES ( "8","");
INSERT INTO `production_ID`  VALUES ( "9","");
INSERT INTO `production_ID`  VALUES ( "10","");
INSERT INTO `production_ID`  VALUES ( "11","");
INSERT INTO `production_ID`  VALUES ( "12","");
INSERT INTO `production_ID`  VALUES ( "13","");
INSERT INTO `production_ID`  VALUES ( "14","");
INSERT INTO `production_ID`  VALUES ( "15","");
INSERT INTO `production_ID`  VALUES ( "16","");
INSERT INTO `production_ID`  VALUES ( "17","");
INSERT INTO `production_ID`  VALUES ( "18","");
INSERT INTO `production_ID`  VALUES ( "19","");
INSERT INTO `production_ID`  VALUES ( "20","");
INSERT INTO `production_ID`  VALUES ( "21","");
INSERT INTO `production_ID`  VALUES ( "22","");
INSERT INTO `production_ID`  VALUES ( "23","");
INSERT INTO `production_ID`  VALUES ( "24","");
INSERT INTO `production_ID`  VALUES ( "25","");
INSERT INTO `production_ID`  VALUES ( "26","");
INSERT INTO `production_ID`  VALUES ( "27","");
INSERT INTO `production_ID`  VALUES ( "28","");
INSERT INTO `production_ID`  VALUES ( "29","");
INSERT INTO `production_ID`  VALUES ( "30","");
INSERT INTO `production_ID`  VALUES ( "31","");
INSERT INTO `production_ID`  VALUES ( "32","");
INSERT INTO `production_ID`  VALUES ( "33","");
INSERT INTO `production_ID`  VALUES ( "34","");
INSERT INTO `production_ID`  VALUES ( "35","");
INSERT INTO `production_ID`  VALUES ( "36","");
INSERT INTO `production_ID`  VALUES ( "37","");
INSERT INTO `production_ID`  VALUES ( "38","");
INSERT INTO `production_ID`  VALUES ( "39","");
INSERT INTO `production_ID`  VALUES ( "40","");
INSERT INTO `production_ID`  VALUES ( "41","");
INSERT INTO `production_ID`  VALUES ( "42","");
INSERT INTO `production_ID`  VALUES ( "43","");
INSERT INTO `production_ID`  VALUES ( "44","");
INSERT INTO `production_ID`  VALUES ( "45","");
INSERT INTO `production_ID`  VALUES ( "46","");
INSERT INTO `production_ID`  VALUES ( "47","");
INSERT INTO `production_ID`  VALUES ( "48","");
INSERT INTO `production_ID`  VALUES ( "49","");
INSERT INTO `production_ID`  VALUES ( "50","");
INSERT INTO `production_ID`  VALUES ( "51","");
INSERT INTO `production_ID`  VALUES ( "52","");
INSERT INTO `production_ID`  VALUES ( "53","");
INSERT INTO `production_ID`  VALUES ( "54","");
INSERT INTO `production_ID`  VALUES ( "55","");
INSERT INTO `production_ID`  VALUES ( "56","");
INSERT INTO `production_ID`  VALUES ( "57","");
INSERT INTO `production_ID`  VALUES ( "58","");
INSERT INTO `production_ID`  VALUES ( "59","");
INSERT INTO `production_ID`  VALUES ( "60","");
INSERT INTO `production_ID`  VALUES ( "61","");
INSERT INTO `production_ID`  VALUES ( "62","");
INSERT INTO `production_ID`  VALUES ( "63","");
INSERT INTO `production_ID`  VALUES ( "64","");
INSERT INTO `production_ID`  VALUES ( "65","");
INSERT INTO `production_ID`  VALUES ( "66","");
INSERT INTO `production_ID`  VALUES ( "67","");
INSERT INTO `production_ID`  VALUES ( "68","");
INSERT INTO `production_ID`  VALUES ( "69","");
INSERT INTO `production_ID`  VALUES ( "70","");
INSERT INTO `production_ID`  VALUES ( "71","");
INSERT INTO `production_ID`  VALUES ( "72","");
INSERT INTO `production_ID`  VALUES ( "73","");
INSERT INTO `production_ID`  VALUES ( "74","");
INSERT INTO `production_ID`  VALUES ( "75","");
INSERT INTO `production_ID`  VALUES ( "76","");
INSERT INTO `production_ID`  VALUES ( "77","");
INSERT INTO `production_ID`  VALUES ( "78","");
INSERT INTO `production_ID`  VALUES ( "79","");
INSERT INTO `production_ID`  VALUES ( "80","");
INSERT INTO `production_ID`  VALUES ( "81","");
INSERT INTO `production_ID`  VALUES ( "82","");
INSERT INTO `production_ID`  VALUES ( "83","");
INSERT INTO `production_ID`  VALUES ( "84","");
INSERT INTO `production_ID`  VALUES ( "85","");
INSERT INTO `production_ID`  VALUES ( "86","");
INSERT INTO `production_ID`  VALUES ( "87","");
INSERT INTO `production_ID`  VALUES ( "88","");
INSERT INTO `production_ID`  VALUES ( "89","");
INSERT INTO `production_ID`  VALUES ( "90","");
INSERT INTO `production_ID`  VALUES ( "91","");
INSERT INTO `production_ID`  VALUES ( "92","");
INSERT INTO `production_ID`  VALUES ( "93","");
INSERT INTO `production_ID`  VALUES ( "94","");
INSERT INTO `production_ID`  VALUES ( "95","");
INSERT INTO `production_ID`  VALUES ( "96","");
INSERT INTO `production_ID`  VALUES ( "97","");
INSERT INTO `production_ID`  VALUES ( "98","");
INSERT INTO `production_ID`  VALUES ( "99","");
INSERT INTO `production_ID`  VALUES ( "100","");
INSERT INTO `production_ID`  VALUES ( "101","");
INSERT INTO `production_ID`  VALUES ( "102","");
INSERT INTO `production_ID`  VALUES ( "103","");
INSERT INTO `production_ID`  VALUES ( "104","");
INSERT INTO `production_ID`  VALUES ( "105","");
INSERT INTO `production_ID`  VALUES ( "106","");
INSERT INTO `production_ID`  VALUES ( "107","");
INSERT INTO `production_ID`  VALUES ( "108","");
INSERT INTO `production_ID`  VALUES ( "109","");
INSERT INTO `production_ID`  VALUES ( "110","");
INSERT INTO `production_ID`  VALUES ( "111","");
INSERT INTO `production_ID`  VALUES ( "112","");
INSERT INTO `production_ID`  VALUES ( "113","");
INSERT INTO `production_ID`  VALUES ( "114","");
INSERT INTO `production_ID`  VALUES ( "115","");
INSERT INTO `production_ID`  VALUES ( "116","");
INSERT INTO `production_ID`  VALUES ( "117","");
INSERT INTO `production_ID`  VALUES ( "118","");
INSERT INTO `production_ID`  VALUES ( "119","");
INSERT INTO `production_ID`  VALUES ( "120","");
INSERT INTO `production_ID`  VALUES ( "121","");
INSERT INTO `production_ID`  VALUES ( "122","");
INSERT INTO `production_ID`  VALUES ( "123","");
INSERT INTO `production_ID`  VALUES ( "124","");
INSERT INTO `production_ID`  VALUES ( "125","");
INSERT INTO `production_ID`  VALUES ( "126","");
INSERT INTO `production_ID`  VALUES ( "127","");
INSERT INTO `production_ID`  VALUES ( "128","");
INSERT INTO `production_ID`  VALUES ( "129","");
INSERT INTO `production_ID`  VALUES ( "130","");
INSERT INTO `production_ID`  VALUES ( "131","");
INSERT INTO `production_ID`  VALUES ( "132","");
INSERT INTO `production_ID`  VALUES ( "133","");
INSERT INTO `production_ID`  VALUES ( "134","");
INSERT INTO `production_ID`  VALUES ( "135","");
INSERT INTO `production_ID`  VALUES ( "136","");
INSERT INTO `production_ID`  VALUES ( "137","");
INSERT INTO `production_ID`  VALUES ( "138","");
INSERT INTO `production_ID`  VALUES ( "139","");
INSERT INTO `production_ID`  VALUES ( "140","");
INSERT INTO `production_ID`  VALUES ( "141","");
INSERT INTO `production_ID`  VALUES ( "142","");
INSERT INTO `production_ID`  VALUES ( "143","");
INSERT INTO `production_ID`  VALUES ( "144","");
INSERT INTO `production_ID`  VALUES ( "145","");
INSERT INTO `production_ID`  VALUES ( "146","");
INSERT INTO `production_ID`  VALUES ( "147","");
INSERT INTO `production_ID`  VALUES ( "148","");
INSERT INTO `production_ID`  VALUES ( "149","");
INSERT INTO `production_ID`  VALUES ( "150","");
INSERT INTO `production_ID`  VALUES ( "151","");
INSERT INTO `production_ID`  VALUES ( "152","");
INSERT INTO `production_ID`  VALUES ( "153","");
INSERT INTO `production_ID`  VALUES ( "154","");
INSERT INTO `production_ID`  VALUES ( "155","");
INSERT INTO `production_ID`  VALUES ( "156","");
INSERT INTO `production_ID`  VALUES ( "157","");
INSERT INTO `production_ID`  VALUES ( "158","");
INSERT INTO `production_ID`  VALUES ( "159","");
INSERT INTO `production_ID`  VALUES ( "160","");
INSERT INTO `production_ID`  VALUES ( "161","");
INSERT INTO `production_ID`  VALUES ( "162","");
INSERT INTO `production_ID`  VALUES ( "163","");
INSERT INTO `production_ID`  VALUES ( "164","");
INSERT INTO `production_ID`  VALUES ( "165","");
INSERT INTO `production_ID`  VALUES ( "166","");
INSERT INTO `production_ID`  VALUES ( "167","");
INSERT INTO `production_ID`  VALUES ( "168","");
INSERT INTO `production_ID`  VALUES ( "169","");
INSERT INTO `production_ID`  VALUES ( "170","");
INSERT INTO `production_ID`  VALUES ( "171","");
INSERT INTO `production_ID`  VALUES ( "172","");
INSERT INTO `production_ID`  VALUES ( "173","");
INSERT INTO `production_ID`  VALUES ( "174","");
INSERT INTO `production_ID`  VALUES ( "175","");
INSERT INTO `production_ID`  VALUES ( "176","");
INSERT INTO `production_ID`  VALUES ( "177","");
INSERT INTO `production_ID`  VALUES ( "178","");
INSERT INTO `production_ID`  VALUES ( "179","");
INSERT INTO `production_ID`  VALUES ( "180","");
INSERT INTO `production_ID`  VALUES ( "181","");
INSERT INTO `production_ID`  VALUES ( "182","");
INSERT INTO `production_ID`  VALUES ( "183","");
INSERT INTO `production_ID`  VALUES ( "184","");
INSERT INTO `production_ID`  VALUES ( "185","");
INSERT INTO `production_ID`  VALUES ( "186","");
INSERT INTO `production_ID`  VALUES ( "187","");
INSERT INTO `production_ID`  VALUES ( "188","");
INSERT INTO `production_ID`  VALUES ( "189","");
INSERT INTO `production_ID`  VALUES ( "190","");
INSERT INTO `production_ID`  VALUES ( "191","");
INSERT INTO `production_ID`  VALUES ( "192","");
INSERT INTO `production_ID`  VALUES ( "193","");
INSERT INTO `production_ID`  VALUES ( "194","");
INSERT INTO `production_ID`  VALUES ( "195","");
INSERT INTO `production_ID`  VALUES ( "196","");
INSERT INTO `production_ID`  VALUES ( "197","");
INSERT INTO `production_ID`  VALUES ( "198","");
INSERT INTO `production_ID`  VALUES ( "199","");
INSERT INTO `production_ID`  VALUES ( "200","");
INSERT INTO `production_ID`  VALUES ( "201","");
INSERT INTO `production_ID`  VALUES ( "202","");
INSERT INTO `production_ID`  VALUES ( "203","");
INSERT INTO `production_ID`  VALUES ( "204","");
INSERT INTO `production_ID`  VALUES ( "205","");
INSERT INTO `production_ID`  VALUES ( "206","");
INSERT INTO `production_ID`  VALUES ( "207","");
INSERT INTO `production_ID`  VALUES ( "208","");
INSERT INTO `production_ID`  VALUES ( "209","");
INSERT INTO `production_ID`  VALUES ( "210","");
INSERT INTO `production_ID`  VALUES ( "211","");
INSERT INTO `production_ID`  VALUES ( "212","");
INSERT INTO `production_ID`  VALUES ( "213","");
INSERT INTO `production_ID`  VALUES ( "214","");
INSERT INTO `production_ID`  VALUES ( "215","");
INSERT INTO `production_ID`  VALUES ( "216","");
INSERT INTO `production_ID`  VALUES ( "217","");
INSERT INTO `production_ID`  VALUES ( "218","");
INSERT INTO `production_ID`  VALUES ( "219","");
INSERT INTO `production_ID`  VALUES ( "220","");
INSERT INTO `production_ID`  VALUES ( "221","");
INSERT INTO `production_ID`  VALUES ( "222","");
INSERT INTO `production_ID`  VALUES ( "223","");
INSERT INTO `production_ID`  VALUES ( "224","");
INSERT INTO `production_ID`  VALUES ( "225","");
INSERT INTO `production_ID`  VALUES ( "226","");
INSERT INTO `production_ID`  VALUES ( "227","");
INSERT INTO `production_ID`  VALUES ( "228","");
INSERT INTO `production_ID`  VALUES ( "229","");
INSERT INTO `production_ID`  VALUES ( "230","");
INSERT INTO `production_ID`  VALUES ( "231","");
INSERT INTO `production_ID`  VALUES ( "232","");
INSERT INTO `production_ID`  VALUES ( "233","");
INSERT INTO `production_ID`  VALUES ( "234","");
INSERT INTO `production_ID`  VALUES ( "235","");
INSERT INTO `production_ID`  VALUES ( "236","");
INSERT INTO `production_ID`  VALUES ( "237","");
INSERT INTO `production_ID`  VALUES ( "238","");
INSERT INTO `production_ID`  VALUES ( "239","");
INSERT INTO `production_ID`  VALUES ( "240","");
INSERT INTO `production_ID`  VALUES ( "241","");
INSERT INTO `production_ID`  VALUES ( "242","");
INSERT INTO `production_ID`  VALUES ( "243","");
INSERT INTO `production_ID`  VALUES ( "244","");
INSERT INTO `production_ID`  VALUES ( "245","");
INSERT INTO `production_ID`  VALUES ( "246","");
INSERT INTO `production_ID`  VALUES ( "247","");
INSERT INTO `production_ID`  VALUES ( "248","");
INSERT INTO `production_ID`  VALUES ( "249","");
INSERT INTO `production_ID`  VALUES ( "250","");
INSERT INTO `production_ID`  VALUES ( "251","");
INSERT INTO `production_ID`  VALUES ( "252","");
INSERT INTO `production_ID`  VALUES ( "253","");
INSERT INTO `production_ID`  VALUES ( "254","");
INSERT INTO `production_ID`  VALUES ( "255","");
INSERT INTO `production_ID`  VALUES ( "256","");
INSERT INTO `production_ID`  VALUES ( "257","");
INSERT INTO `production_ID`  VALUES ( "258","");
INSERT INTO `production_ID`  VALUES ( "259","");
INSERT INTO `production_ID`  VALUES ( "260","");
INSERT INTO `production_ID`  VALUES ( "261","");
INSERT INTO `production_ID`  VALUES ( "262","");
INSERT INTO `production_ID`  VALUES ( "263","");
INSERT INTO `production_ID`  VALUES ( "264","");
INSERT INTO `production_ID`  VALUES ( "265","");
INSERT INTO `production_ID`  VALUES ( "266","");
INSERT INTO `production_ID`  VALUES ( "267","");
INSERT INTO `production_ID`  VALUES ( "268","");
INSERT INTO `production_ID`  VALUES ( "269","");
INSERT INTO `production_ID`  VALUES ( "270","");
INSERT INTO `production_ID`  VALUES ( "271","");
INSERT INTO `production_ID`  VALUES ( "272","");
INSERT INTO `production_ID`  VALUES ( "273","");
INSERT INTO `production_ID`  VALUES ( "274","");
INSERT INTO `production_ID`  VALUES ( "275","");
INSERT INTO `production_ID`  VALUES ( "276","");
INSERT INTO `production_ID`  VALUES ( "277","");
INSERT INTO `production_ID`  VALUES ( "278","");
INSERT INTO `production_ID`  VALUES ( "279","");
INSERT INTO `production_ID`  VALUES ( "280","");
INSERT INTO `production_ID`  VALUES ( "281","");
INSERT INTO `production_ID`  VALUES ( "282","");
INSERT INTO `production_ID`  VALUES ( "283","");
INSERT INTO `production_ID`  VALUES ( "284","");
INSERT INTO `production_ID`  VALUES ( "285","");
INSERT INTO `production_ID`  VALUES ( "286","");
INSERT INTO `production_ID`  VALUES ( "287","");
INSERT INTO `production_ID`  VALUES ( "288","");
INSERT INTO `production_ID`  VALUES ( "289","");
INSERT INTO `production_ID`  VALUES ( "290","");
INSERT INTO `production_ID`  VALUES ( "291","");
INSERT INTO `production_ID`  VALUES ( "292","");
INSERT INTO `production_ID`  VALUES ( "293","");
INSERT INTO `production_ID`  VALUES ( "294","");
INSERT INTO `production_ID`  VALUES ( "295","");
INSERT INTO `production_ID`  VALUES ( "296","");
INSERT INTO `production_ID`  VALUES ( "297","");
INSERT INTO `production_ID`  VALUES ( "298","");
INSERT INTO `production_ID`  VALUES ( "299","");
INSERT INTO `production_ID`  VALUES ( "300","");
INSERT INTO `production_ID`  VALUES ( "301","");
INSERT INTO `production_ID`  VALUES ( "302","");
INSERT INTO `production_ID`  VALUES ( "303","");
INSERT INTO `production_ID`  VALUES ( "304","");
INSERT INTO `production_ID`  VALUES ( "305","");
INSERT INTO `production_ID`  VALUES ( "306","");
INSERT INTO `production_ID`  VALUES ( "307","");
INSERT INTO `production_ID`  VALUES ( "308","");
INSERT INTO `production_ID`  VALUES ( "309","");
INSERT INTO `production_ID`  VALUES ( "310","");
INSERT INTO `production_ID`  VALUES ( "311","");
INSERT INTO `production_ID`  VALUES ( "312","");
INSERT INTO `production_ID`  VALUES ( "313","");
INSERT INTO `production_ID`  VALUES ( "314","");
INSERT INTO `production_ID`  VALUES ( "315","");
INSERT INTO `production_ID`  VALUES ( "316","");
INSERT INTO `production_ID`  VALUES ( "317","");
INSERT INTO `production_ID`  VALUES ( "318","");
INSERT INTO `production_ID`  VALUES ( "319","");
INSERT INTO `production_ID`  VALUES ( "320","");
INSERT INTO `production_ID`  VALUES ( "321","");
INSERT INTO `production_ID`  VALUES ( "322","");
INSERT INTO `production_ID`  VALUES ( "323","");
INSERT INTO `production_ID`  VALUES ( "324","");
INSERT INTO `production_ID`  VALUES ( "325","");
INSERT INTO `production_ID`  VALUES ( "326","");
INSERT INTO `production_ID`  VALUES ( "327","");
INSERT INTO `production_ID`  VALUES ( "328","");
INSERT INTO `production_ID`  VALUES ( "329","");
INSERT INTO `production_ID`  VALUES ( "330","");
INSERT INTO `production_ID`  VALUES ( "331","");
INSERT INTO `production_ID`  VALUES ( "332","");
INSERT INTO `production_ID`  VALUES ( "333","");
INSERT INTO `production_ID`  VALUES ( "334","");
INSERT INTO `production_ID`  VALUES ( "335","");
INSERT INTO `production_ID`  VALUES ( "336","");
INSERT INTO `production_ID`  VALUES ( "337","");
INSERT INTO `production_ID`  VALUES ( "338","");
INSERT INTO `production_ID`  VALUES ( "339","");
INSERT INTO `production_ID`  VALUES ( "340","");
INSERT INTO `production_ID`  VALUES ( "341","");
INSERT INTO `production_ID`  VALUES ( "342","");
INSERT INTO `production_ID`  VALUES ( "343","");
INSERT INTO `production_ID`  VALUES ( "344","");
INSERT INTO `production_ID`  VALUES ( "345","");
INSERT INTO `production_ID`  VALUES ( "346","");
INSERT INTO `production_ID`  VALUES ( "347","");
INSERT INTO `production_ID`  VALUES ( "348","");
INSERT INTO `production_ID`  VALUES ( "349","");
INSERT INTO `production_ID`  VALUES ( "350","");
INSERT INTO `production_ID`  VALUES ( "351","");
INSERT INTO `production_ID`  VALUES ( "352","");
INSERT INTO `production_ID`  VALUES ( "353","");
INSERT INTO `production_ID`  VALUES ( "354","");
INSERT INTO `production_ID`  VALUES ( "355","");
INSERT INTO `production_ID`  VALUES ( "356","");
INSERT INTO `production_ID`  VALUES ( "357","");
INSERT INTO `production_ID`  VALUES ( "358","");
INSERT INTO `production_ID`  VALUES ( "359","");
INSERT INTO `production_ID`  VALUES ( "360","");
INSERT INTO `production_ID`  VALUES ( "361","");
INSERT INTO `production_ID`  VALUES ( "362","");
INSERT INTO `production_ID`  VALUES ( "363","");
INSERT INTO `production_ID`  VALUES ( "364","");
INSERT INTO `production_ID`  VALUES ( "365","");
INSERT INTO `production_ID`  VALUES ( "366","");
INSERT INTO `production_ID`  VALUES ( "367","");
INSERT INTO `production_ID`  VALUES ( "368","");
INSERT INTO `production_ID`  VALUES ( "369","");
INSERT INTO `production_ID`  VALUES ( "370","");
INSERT INTO `production_ID`  VALUES ( "371","");
INSERT INTO `production_ID`  VALUES ( "372","");
INSERT INTO `production_ID`  VALUES ( "373","");
INSERT INTO `production_ID`  VALUES ( "374","");
INSERT INTO `production_ID`  VALUES ( "375","");
INSERT INTO `production_ID`  VALUES ( "376","");
INSERT INTO `production_ID`  VALUES ( "377","");
INSERT INTO `production_ID`  VALUES ( "378","");
INSERT INTO `production_ID`  VALUES ( "379","");
INSERT INTO `production_ID`  VALUES ( "380","");
INSERT INTO `production_ID`  VALUES ( "381","");
INSERT INTO `production_ID`  VALUES ( "382","");
INSERT INTO `production_ID`  VALUES ( "383","");
INSERT INTO `production_ID`  VALUES ( "384","");
INSERT INTO `production_ID`  VALUES ( "385","");
INSERT INTO `production_ID`  VALUES ( "386","");
INSERT INTO `production_ID`  VALUES ( "387","");
INSERT INTO `production_ID`  VALUES ( "388","");
INSERT INTO `production_ID`  VALUES ( "389","");
INSERT INTO `production_ID`  VALUES ( "390","");
INSERT INTO `production_ID`  VALUES ( "391","");
INSERT INTO `production_ID`  VALUES ( "392","");
INSERT INTO `production_ID`  VALUES ( "393","");
INSERT INTO `production_ID`  VALUES ( "394","");
INSERT INTO `production_ID`  VALUES ( "395","");
INSERT INTO `production_ID`  VALUES ( "396","");
INSERT INTO `production_ID`  VALUES ( "397","");
INSERT INTO `production_ID`  VALUES ( "398","");
INSERT INTO `production_ID`  VALUES ( "399","");
INSERT INTO `production_ID`  VALUES ( "400","");
INSERT INTO `production_ID`  VALUES ( "401","");
INSERT INTO `production_ID`  VALUES ( "402","");
INSERT INTO `production_ID`  VALUES ( "403","");
INSERT INTO `production_ID`  VALUES ( "404","");
INSERT INTO `production_ID`  VALUES ( "405","");
INSERT INTO `production_ID`  VALUES ( "406","");
INSERT INTO `production_ID`  VALUES ( "407","");
INSERT INTO `production_ID`  VALUES ( "408","");
INSERT INTO `production_ID`  VALUES ( "409","");
INSERT INTO `production_ID`  VALUES ( "410","");
INSERT INTO `production_ID`  VALUES ( "411","");
INSERT INTO `production_ID`  VALUES ( "412","");
INSERT INTO `production_ID`  VALUES ( "413","");
INSERT INTO `production_ID`  VALUES ( "414","");
INSERT INTO `production_ID`  VALUES ( "415","");
INSERT INTO `production_ID`  VALUES ( "416","");
INSERT INTO `production_ID`  VALUES ( "417","");
INSERT INTO `production_ID`  VALUES ( "418","");
INSERT INTO `production_ID`  VALUES ( "419","");
INSERT INTO `production_ID`  VALUES ( "420","");
INSERT INTO `production_ID`  VALUES ( "421","");
INSERT INTO `production_ID`  VALUES ( "422","");
INSERT INTO `production_ID`  VALUES ( "423","");
INSERT INTO `production_ID`  VALUES ( "424","");
INSERT INTO `production_ID`  VALUES ( "425","");
INSERT INTO `production_ID`  VALUES ( "426","");
INSERT INTO `production_ID`  VALUES ( "427","");
INSERT INTO `production_ID`  VALUES ( "428","");
INSERT INTO `production_ID`  VALUES ( "429","");
INSERT INTO `production_ID`  VALUES ( "430","");
INSERT INTO `production_ID`  VALUES ( "431","");
INSERT INTO `production_ID`  VALUES ( "432","");
INSERT INTO `production_ID`  VALUES ( "433","");
INSERT INTO `production_ID`  VALUES ( "434","");
INSERT INTO `production_ID`  VALUES ( "435","");
INSERT INTO `production_ID`  VALUES ( "436","");
INSERT INTO `production_ID`  VALUES ( "437","");
INSERT INTO `production_ID`  VALUES ( "438","");
INSERT INTO `production_ID`  VALUES ( "439","");
INSERT INTO `production_ID`  VALUES ( "440","");
INSERT INTO `production_ID`  VALUES ( "441","");
INSERT INTO `production_ID`  VALUES ( "442","");
INSERT INTO `production_ID`  VALUES ( "443","");
INSERT INTO `production_ID`  VALUES ( "444","");
INSERT INTO `production_ID`  VALUES ( "445","");


--
-- Tabel structure for table `species`
--
DROP TABLE  IF EXISTS `species`;
CREATE TABLE `species` (
  `scientific` varchar(45) NOT NULL,
  `common` varchar(45) NOT NULL,
  PRIMARY KEY (`common`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `species`  VALUES ( "Tunnus alalunga","Albacore");
INSERT INTO `species`  VALUES ( "Sarda sarda","Atlantic bonito");
INSERT INTO `species`  VALUES ( "Brama brama","Atlantic pomfret");
INSERT INTO `species`  VALUES ( "Sphyraena sphyraena","Barracuda");
INSERT INTO `species`  VALUES ( "Alopias superciliosus","Bigeye thresher");
INSERT INTO `species`  VALUES ( "Spondyliosoma cantharus","Black seabream");
INSERT INTO `species`  VALUES ( "Euthynnus alleteratus","Black skipjack");
INSERT INTO `species`  VALUES ( "Centrolophus niger","Blackfish");
INSERT INTO `species`  VALUES ( "Dasyatis violacea","Blue stingray");
INSERT INTO `species`  VALUES ( "Prionace glauca","Blue-shark");
INSERT INTO `species`  VALUES ( "Auxis rochei","Bullet tuna");
INSERT INTO `species`  VALUES ( "Scomber japonicus","Chub mackerel");
INSERT INTO `species`  VALUES ( "Dasyatis pastinaca","Common stingray");
INSERT INTO `species`  VALUES ( "Calonectris diomedea","Cory's Shearwater");
INSERT INTO `species`  VALUES ( "Mobula mobular","Devil ray");
INSERT INTO `species`  VALUES ( "Epinephelus caninus","Dogtooth grouper");
INSERT INTO `species`  VALUES ( "Coryphaena hippurus","Dolphin-fish");
INSERT INTO `species`  VALUES ( "Epinephelus guaza","Dusky grouper");
INSERT INTO `species`  VALUES ( "Myliobatidae","Eagle or Bull ray");
INSERT INTO `species`  VALUES ( "Anguillidae","Eel");
INSERT INTO `species`  VALUES ( "Conger conger","European conger");
INSERT INTO `species`  VALUES ( "Merluccius merluccius","European hake");
INSERT INTO `species`  VALUES ( "Phycis spp","Forkbeard");
INSERT INTO `species`  VALUES ( "Auxis thazard","Frigate tuna");
INSERT INTO `species`  VALUES ( "Epinephelus alexandrinus","Golden grouper");
INSERT INTO `species`  VALUES ( "Schedophilus ovalis","Imperial blackfish");
INSERT INTO `species`  VALUES ( "Lichia amia","Leerfish");
INSERT INTO `species`  VALUES ( "Trachurus spp","Mackerels");
INSERT INTO `species`  VALUES ( "Muraena helena","Med. Morey");
INSERT INTO `species`  VALUES ( "Ommastrephes bartrami","Neon Flying Squid");
INSERT INTO `species`  VALUES ( "Ruvettus pretiosus","Oilfish");
INSERT INTO `species`  VALUES ( "Squalus acanthias","Piked dogfish");
INSERT INTO `species`  VALUES ( "Dasyatidae","Ray");
INSERT INTO `species`  VALUES ( "Trachipterus trachypterus","Ribbon fish");
INSERT INTO `species`  VALUES ( "Carcharhinus plumbeus","Sandbar shark");
INSERT INTO `species`  VALUES ( "Scorpaena spp","Scorpion/Rockfish");
INSERT INTO `species`  VALUES ( "Sea-turtle","Sea-turtle");
INSERT INTO `species`  VALUES ( "Seagull","Seagull");
INSERT INTO `species`  VALUES ( "Shark","Shark");
INSERT INTO `species`  VALUES ( "Isurus oxyrinchus","Shortfin mako");
INSERT INTO `species`  VALUES ( "Lepidopus caudatus","Silver scabbardfish");
INSERT INTO `species`  VALUES ( "Sphyraena zygaena","Smooth hummerhead");
INSERT INTO `species`  VALUES ( "Tetrapterus belone","Spearfish");
INSERT INTO `species`  VALUES ( "Squalidae","Squalus");
INSERT INTO `species`  VALUES ( "Cephalopods","Squid");
INSERT INTO `species`  VALUES ( "Dasyatidae","Stingrays");
INSERT INTO `species`  VALUES ( "Mola mola","Sunfish");
INSERT INTO `species`  VALUES ( "Xiphias gladius","Swordfish");
INSERT INTO `species`  VALUES ( "Alopias vulpinus","Thresher shark");
INSERT INTO `species`  VALUES ( "Galeorhinus galeus","Tope shark");
INSERT INTO `species`  VALUES ( "Carcharodon carcharias","White-shark");
INSERT INTO `species`  VALUES ( "Polyprion americanus","Wreckfish");


--
-- Tabel structure for table `species_measurements`
--
DROP TABLE  IF EXISTS `species_measurements`;
CREATE TABLE `species_measurements` (
  `measure_expedition_ID` int(11) NOT NULL,
  `species` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `measure_ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`measure_ID`),
  UNIQUE KEY `measure_ID_UNIQUE` (`measure_ID`),
  KEY `expedition_ID_idx` (`measure_expedition_ID`),
  CONSTRAINT `measure_expedition_ID` FOREIGN KEY (`measure_expedition_ID`) REFERENCES `vessel_expeditions` (`expedition_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=greek;



--
-- Tabel structure for table `users`
--
DROP TABLE  IF EXISTS `users`;
CREATE TABLE `users` (
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `privileges` varchar(45) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_logout` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`username`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=greek;

INSERT INTO `users`  VALUES ( "admin1","0","admin","2014-01-11 00:02:30","2013-12-24 10:02:59");
INSERT INTO `users`  VALUES ( "enaspanw","enaskatw","user","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO `users`  VALUES ( "GeorgePatelis","123456","user","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO `users`  VALUES ( "moderator1","0","moderator","2014-01-05 23:26:13","0000-00-00 00:00:00");
INSERT INTO `users`  VALUES ( "user1","0","user","2014-01-09 16:32:57","2013-12-20 22:31:47");
INSERT INTO `users`  VALUES ( "vagsmyrn","12345","user","0000-00-00 00:00:00","0000-00-00 00:00:00");


--
-- Tabel structure for table `users_action_history`
--
DROP TABLE  IF EXISTS `users_action_history`;
CREATE TABLE `users_action_history` (
  `action_ID` int(11) NOT NULL AUTO_INCREMENT,
  `action_username` varchar(45) DEFAULT NULL,
  `action_AMAS` varchar(45) DEFAULT NULL,
  `action_vproduction_ID` int(11) DEFAULT NULL,
  `action_pproduction_ID` int(11) DEFAULT NULL,
  `action_eexpedition_ID` int(11) DEFAULT NULL,
  `action_size_expedition_ID` int(11) DEFAULT NULL,
  `action_ALBmeasure` int(11) DEFAULT NULL,
  `action_BFTmeasure` int(11) DEFAULT NULL,
  `action_RVTmeasure` int(11) DEFAULT NULL,
  `action_SWOmeasure` int(11) DEFAULT NULL,
  `action_OTHERmeasure` int(11) DEFAULT NULL,
  `action_newuser` varchar(45) DEFAULT NULL,
  `action_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`action_ID`),
  KEY `username` (`action_username`),
  KEY `username_2` (`action_username`),
  KEY `username_3` (`action_username`),
  KEY `username_4` (`action_username`),
  KEY `action_AMAS` (`action_AMAS`,`action_vproduction_ID`,`action_pproduction_ID`,`action_eexpedition_ID`,`action_size_expedition_ID`,`action_ALBmeasure`,`action_BFTmeasure`,`action_RVTmeasure`,`action_SWOmeasure`,`action_OTHERmeasure`),
  KEY `action_production_ID` (`action_vproduction_ID`,`action_pproduction_ID`,`action_eexpedition_ID`,`action_size_expedition_ID`,`action_ALBmeasure`,`action_BFTmeasure`,`action_RVTmeasure`,`action_SWOmeasure`,`action_OTHERmeasure`),
  KEY `action_vproduction_ID` (`action_vproduction_ID`),
  KEY `action_pproduction_ID` (`action_pproduction_ID`),
  KEY `action_eexpedition_ID` (`action_eexpedition_ID`),
  KEY `action_size_expedition_ID` (`action_size_expedition_ID`),
  KEY `action_ALBmeasure` (`action_ALBmeasure`),
  KEY `action_BFTmeasure` (`action_BFTmeasure`),
  KEY `action_RVTmeasure` (`action_RVTmeasure`),
  KEY `action_SWOmeasure` (`action_SWOmeasure`),
  KEY `action_OTHERmeasure` (`action_OTHERmeasure`),
  CONSTRAINT `users_action_history_ibfk_1` FOREIGN KEY (`action_username`) REFERENCES `users` (`username`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_10` FOREIGN KEY (`action_ALBmeasure`) REFERENCES `ALBmeasure` (`ALB_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_11` FOREIGN KEY (`action_BFTmeasure`) REFERENCES `BFTmeasure` (`BFT_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_12` FOREIGN KEY (`action_RVTmeasure`) REFERENCES `RVTmeasure` (`RVT_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_13` FOREIGN KEY (`action_SWOmeasure`) REFERENCES `SWOmeasure` (`SWO_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_14` FOREIGN KEY (`action_OTHERmeasure`) REFERENCES `OTHERmeasure` (`OTHER_measure_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_2` FOREIGN KEY (`action_AMAS`) REFERENCES `vessel` (`AMAS`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_4` FOREIGN KEY (`action_vproduction_ID`) REFERENCES `dynamic_vessel` (`vessel_production_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_5` FOREIGN KEY (`action_pproduction_ID`) REFERENCES `production` (`production_ID`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `users_action_history_ibfk_8` FOREIGN KEY (`action_size_expedition_ID`) REFERENCES `expedition_size` (`size_expedition_ID`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=greek;

INSERT INTO `users_action_history`  VALUES ( "12","admin1","","","","","","","","","","","GeorgePatelis","0000-00-00 00:00:00");
INSERT INTO `users_action_history`  VALUES ( "13","admin1","","","","","","","","","","","enaspanw","2014-01-11 00:47:27");


--
-- Tabel structure for table `vessel`
--
DROP TABLE  IF EXISTS `vessel`;
CREATE TABLE `vessel` (
  `AMAS` varchar(45) CHARACTER SET greek NOT NULL,
  `vessel_name` varchar(45) DEFAULT NULL,
  `reg_no_state` varchar(45) DEFAULT NULL,
  `port` varchar(45) DEFAULT NULL,
  `port_area` varchar(45) DEFAULT NULL,
  `grt` varchar(45) DEFAULT NULL,
  `vl` varchar(45) DEFAULT NULL,
  `vlc` varchar(45) DEFAULT NULL,
  `vw` varchar(45) DEFAULT NULL,
  `hp` varchar(45) DEFAULT NULL,
  `gears` varchar(45) NOT NULL,
  `navigation` varchar(100) DEFAULT NULL,
  `communication` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`AMAS`),
  UNIQUE KEY `AMAS_UNIQUE` (`AMAS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `vessel`  VALUES ( "1","???? ??????","440","HAN","","11,6099996567","11,8999996185","1","4","148","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "10","???????","?.?. 132","HAN","","28,0300006866","13,1999998093","","4,5999999046","150","?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "1009","??????","?.?. 93","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "101","??????","?.?. 196","HAN","","","18","2","","","","","");
INSERT INTO `vessel`  VALUES ( "1016","??????","?.?. 276","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1017","???????","?.?. 96","OTH","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1018","???????","?.?. 413","OTH","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1020","????????","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1021","?????????","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1022","Happiness","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1023","??????????","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1024","???. ????????","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1045","???????","?.??","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "105","???. ??????? ?","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1061","???. ???????","","KAL","","","","2","","","","","");
INSERT INTO `vessel`  VALUES ( "1062","??. ????????","?.?. 160","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1063","??????","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1065","????????","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "107","??????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1070","??????","","OTH","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "1073","Hellenic Spirit","","OTH","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "11","????????","?.?. 476","HAN","","8,8599996567","9,1000003815","","3,4000000954","48","?,?,?","PX","VHF");
INSERT INTO `vessel`  VALUES ( "111","???????? ?","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "113","?? ??? ???????","?.?. 196","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "119","?????????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "12","???????? ?.","?.?. 137","HAN","","47,7000007629","17,7000007629","","5,2300000191","150","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "125","????????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "128","??. ????????","?.?. 271","KAL","","8","11","1","3","60","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "129","???/???","?.?. 62","KAL","","13","13","1","4","75","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "13","?????????","?.?. 496","HAN","","19,6000003815","15,4499998093","","4,9800000191","150","?,?,?,???","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "130","??????? ?????","?.?. 75","KAL","","19","13,6499996185","1","4,5","210","?,?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "131","??????","?.?. 59","KAL","","21,0300006866","14,3000001907","1","4,5900001526","160","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "132","??. ????????","?.?. 95","KAL","","22,3700008392","13","1","","220","","R","");
INSERT INTO `vessel`  VALUES ( "133","??????","?.?. 101","KAL","","23,2099990845","14,3999996185","1","5","195","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "134","????","?.?. 99","KAL","","23,2099990845","14,3999996185","1","5","120","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "135","??????","?.?. 62","KAL","","26","15,3000001907","1","5","185","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "136","??. ????????","?.?. 47","KAL","","26,3700008392","15,5","2","5","195","?,?????.","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "137","?????????? ?.","?.?. 139","KAL","","28,7999992371","15,5","2","4,6799998283","220","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "138","??????? ????????","?.?. 64","KAL","","31,9699993134","17","2","5,6500000954","400","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "139","???. ??????","?.?. 92","KAL","","33,8600006104","15,6700000763","2","5","240","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "14","???????","?.?. 386","HAN","","28,0499992371","13,8000001907","","4,5","148","?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "140","?????-????????","?.?. 109","KAL","","39,9000015259","16","2","5,4000000954","220","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "141","????????","?.?. 112","KAL","","81","23,2199993134","3","7,5","420","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "142","??????","?.?. 53","KAL","","25,2700004578","15","2","5,0999999046","177","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "143","??. ???????? ????????","?.?. 469","KAL","","","","1","","","","","");
INSERT INTO `vessel`  VALUES ( "144","????????1","","KAL","","","","1","","","","","");
INSERT INTO `vessel`  VALUES ( "145","??. ?????????","?.?. 275","KAL","","","","","","","","Radar, GPS Plotter","VHF");
INSERT INTO `vessel`  VALUES ( "146","??? ???????","?.?. 186","KAL","","","","2","","","","","");
INSERT INTO `vessel`  VALUES ( "147","???. ??????????","?.?. 103","KAL","","","","2","","","","","");
INSERT INTO `vessel`  VALUES ( "148","????? ?.","","KAL","","","18","2","","","","","");
INSERT INTO `vessel`  VALUES ( "149","????????","?.?. 392","KAL","","","","1","","","","","");
INSERT INTO `vessel`  VALUES ( "15","?????????","?.?. 413","HAN","","15,1199998856","12,6999998093","","4,25","122","?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "150","??. ??????","?.?. 303","KAL","","10,6800003052","12","1","","","","","");
INSERT INTO `vessel`  VALUES ( "151","??. ????????","?.?. 374","KAL","","7,6999998093","10","1","3,6800000668","80","?,?","RD","VHF");
INSERT INTO `vessel`  VALUES ( "152","????????","","KAL","","","10","","","","?,?","","");
INSERT INTO `vessel`  VALUES ( "153","??. ?????????","?.?. 66","KAL","","24,0799999237","15","","","235","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "154","???? ???????","?.?. 223","KAL","","","","","","","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "155","??????","?.?. 104","KAL","","","","","","","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "157","??. ?????? ?????????????","?.?. 165","KAL","","","12","1","","75","","R","");
INSERT INTO `vessel`  VALUES ( "158","??????? ?.","?.?. 88","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "159","???. ???????","?.?. 219","KAL","","","13","1","","","","Radar","");
INSERT INTO `vessel`  VALUES ( "16","?????????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "160","??. ??????????","?.?. 36","KAL","","","13,5","1","","150","","R","SSB");
INSERT INTO `vessel`  VALUES ( "162","??. ????????","?.?. 164","KAL","","28","14,9499998093","2","5,1799998283","257","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "165","??. ??????","N.K. 397","KAL","","20,3299999237","12","1","4,1999998093","120","?,?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "167","??????????/??????????","?.?. 172","KAL","","23","14,8999996185","1","5,8000001907","110","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "168","?????????? ?.","?.?. 393","KAL","","11,3800001144","18,3500003815","2","5,6500000954","85","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "169","??????? ??????????","?.?. 158","KAL","","27","15","2","6","102","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "17","??????? ??","?.?. 384","HAN","","6,1399998665","8,5500001907","","3,2400000095","115","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "171","??? ???????","?.?. 187","KAL","","","","2","","","","","");
INSERT INTO `vessel`  VALUES ( "172","???????? II","?.?. 161","KAL","","30","15","2","5,4000000954","340","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "175","???. ?????????","?.?. 188","KAL","","22,7999992371","14,9499998093","2","5,6199998856","110","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "177","???. ??????????","?.?. 162","KAL","","20","15","2","5,4000000954","120","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "18","??????? ?","?.?. 180","HAN","","28,2399997711","17,1000003815","","5,3000001907","135","?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "180","????????","?.?. 338","KAL","","","10","","","","?,?","","");
INSERT INTO `vessel`  VALUES ( "181","????? ?.","?.?. 186","KAL","","20,8299999237","16,7199993134","2","5,3499999046","150","?,?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "184","????????-A??????","?.?. 90","KAL","","","17","2","","","","","");
INSERT INTO `vessel`  VALUES ( "185","????????-??????","?.?. 443","KAL","","11,0200004578","17,3999996185","2","5,5999999046","165","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "186","?????","N.K. 452","KAL","","14,5","12,5","1","4","114","?","","");
INSERT INTO `vessel`  VALUES ( "19","????????","?.?. 103","HAN","","13,1400003433","11,8000001907","","3,9000000954","135","?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "194","???????? ??","?.?. 160","KAL","","27,25","15,25","2","5,25","145","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "196","?????????","?.?. 190","KAL","","16","14","1","","","","","");
INSERT INTO `vessel`  VALUES ( "2","???? ???????","122","HAN","","33,7999992371","13,1999998093","","4,5999999046","175","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "20","???? ??? ??","?.?. 376","HAN","","10,1300001144","10,5","","3,7000000477","80","?,?,?","PX","VHF");
INSERT INTO `vessel`  VALUES ( "21","?????? ?","?.?. 447","HAN","","27,8600006104","13,9499998093","","4,5","150","?,?,?","RD","VHF");
INSERT INTO `vessel`  VALUES ( "22","????? ?","?.?.113","HAN","","44,5900001526","17,2000007629","","5,1399998665","150","?,?,?","RD,PX,LR","VHF,SSB");
INSERT INTO `vessel`  VALUES ( "23","????? ?","?.?. 432","HAN","","11,8500003815","11,6999998093","","4,3000001907","145","?,?,?,?","RD","VHF");
INSERT INTO `vessel`  VALUES ( "236","??. ????????","?.?. 194","KAL","","25","18","2","","","","","");
INSERT INTO `vessel`  VALUES ( "238","??. ????????","?.?. 510","KAL","","10,5100002289","14,8500003815","1","5,3000001907","84","?","","");
INSERT INTO `vessel`  VALUES ( "24","?????????","?.?. 429","HAN","","17,9400005341","12,6000003815","","4,3000001907","80","?,?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "25","?? ??? ???????","?.?. 147","HAN","","26,9599990845","13,5","","4,5999999046","150","?,?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "254","?????? ?.","?.?. 479","KAL","","16,5900001526","14,1000003815","1","4,4000000954","180","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "258","?????","N.K. 452","KAL","","14,5","12,5","1","4","114","?","","");
INSERT INTO `vessel`  VALUES ( "26","???????? ??","?.?. 118","HAN","","59","18,6000003815","","5,5999999046","150","?,?,?,?","RD,PX,LR,AP","VHF,SSB");
INSERT INTO `vessel`  VALUES ( "261","??????? ?????","N.K. 75","KAL","","19","13,6499996185","1","4,5","210","?,?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "27","????????????","?.?. 183","HAN","","26,6800003052","19,2999992371","","5,3000001907","150","?,?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "271","Britl","?.?. 164","KAL","","28","14,9499998093","1","5,1799998283","257","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "274","??. ?????????????","","KAL","","27","18","2","","","","","");
INSERT INTO `vessel`  VALUES ( "276","????????","","KAL","","11","17","2","","","","","");
INSERT INTO `vessel`  VALUES ( "28","??????? ??","?.?. 405","HAN","","25,8899993896","13,1999998093","","4,5999999046","150","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "280","?????????","","KAL","","","14","1","","","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "282","???????? II","161","KAL","","30","15","2","5,4000000954","340","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "289","????? ?.","","KAL","","20,8299999237","16,7199993134","2","5,3499999046","150","?,?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "29","????????","?.?. 331","HAN","","2,3900001049","7,0999999046","","2,5","12","?,?,?","","VHF");
INSERT INTO `vessel`  VALUES ( "290","????????","392","KAL","","","14","1","","","","","");
INSERT INTO `vessel`  VALUES ( "295","??????? ????????","N.K. 292","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "296","??????????","","KAL","","","13","","","","","","");
INSERT INTO `vessel`  VALUES ( "297","??????","","KAL","","","12","1","","","?, ?","","");
INSERT INTO `vessel`  VALUES ( "299","??????????","?.?. 422","KAL","","20","15","2","","","","","");
INSERT INTO `vessel`  VALUES ( "3","?????????","475","HAN","","4,9699997902","8,9499998093","","","15","","","");
INSERT INTO `vessel`  VALUES ( "30","???? ??????","?.?. 440","HAN","","11,6099996567","11,8999996185","","4","148","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "301","?????","?.?. 198","KAL","","25","16","","","","","","");
INSERT INTO `vessel`  VALUES ( "307","??. ???/???","?.?. 562","KAL","","15,5","12","1","","75","?, ?","","");
INSERT INTO `vessel`  VALUES ( "31","???? ???????","?.?. 122","HAN","","33,7999992371","13,1999998093","","4,5999999046","175","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "313","????? ??????","N.K. 524","KAL","","11,3800001144","18,2000007629","2","5,3000001907","122","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "32","?????????","?.?. 475","HAN","","4,9699997902","8,9499998093","","","15","","","");
INSERT INTO `vessel`  VALUES ( "321","???. ???????","?.?. 239","KAL","","15,8599996567","13,6000003815","2","","140","?,?","","");
INSERT INTO `vessel`  VALUES ( "328","?????????","?.?. 75","KAL","","19","13,6499996185","2","4,5","210","?,?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "33","??????? ?","?.?. 431","HAN","","10,5500001907","12,5","","3,4000000954","135","?,?,?,?","RD","VHF");
INSERT INTO `vessel`  VALUES ( "332","?????????? ?????","","KAL","","12","12","1","","75","","","");
INSERT INTO `vessel`  VALUES ( "339","????????","?.?. 49","KAL","","14","12","1","","75","?,?-?","","");
INSERT INTO `vessel`  VALUES ( "34","????????","?.?. 133","HAN","","33,7999992371","13,1999998093","","4,5999999046","238","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "346","?????????? ?.","N.K. 393","KAL","","11,3800001144","18,3500003815","2","5,6500000954","85","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "347","???. ?????????","N.K. 188","KAL","","22,7999992371","14,9499998093","2","5,6199998856","110","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "349","???. ??????????","N.K. 162","KAL","","20","15","2","5,4000000954","120","?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "35","?????????","?.?. 126","HAN","","38,2999992371","14,9499998093","","4,6999998093","150","?,?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "353","?????????","N.K. 75","KAL","","19","13,6499996185","2","4,5","210","?,?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "355","????","N.K. 99","KAL","","23,2099990845","14,3999996185","2","5","120","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "356","??????????","N.K. 422","KAL","","20","15","2","","","","","");
INSERT INTO `vessel`  VALUES ( "357","???????? II","N.K. 160","KAL","","27,25","15,25","2","5,25","145","?,?,?????.","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "358","?????","N.K. 198","KAL","","25","16","2","","","?-?-?","","");
INSERT INTO `vessel`  VALUES ( "359","??????","N.K. 59","KAL","","21,0300006866","14,3000001907","2","4,5900001526","160","?,?, ?????? ??? ????","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "36","????????","?.?. 430","HAN","","17,9400005341","12,6000003815","","4,3000001907","150","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "360","????? ??????","?.?. 20","KAL","","4,1999998093","9,9200000763","1","3","40","?,...","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "362","??. ???/???","526","KAL","","15,5","12","1","","75","?, ?","","");
INSERT INTO `vessel`  VALUES ( "364","?????????","N.K. 190","KAL","","16","14","1","","","?,?","","");
INSERT INTO `vessel`  VALUES ( "366","??????????/??????????","N.K. 172","KAL","","23","14,8999996185","1","5,8000001907","110","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "374","??. ?????????","N.K. 530","KAL","","","18","2","","","","","");
INSERT INTO `vessel`  VALUES ( "375","??????? ?.","N.K. 525","KAL","","","15","2","","","","","");
INSERT INTO `vessel`  VALUES ( "376","Britl","164","KAL","","28","14,9499998093","2","5,1799998283","257","?,?","RD,GPS","VHF");
INSERT INTO `vessel`  VALUES ( "381","????????","49","KAL","","14","12","1","","75","?,?-?","","");
INSERT INTO `vessel`  VALUES ( "382","???????","?.?. 183","HAL","","5,1199998856","9,3000001907","","3,5999999046","22,0499992371","?, ??, ?,?,???","","");
INSERT INTO `vessel`  VALUES ( "383","???????","?.?. 194","HAL","","5,1100001335","9,1999998093","","3,5999999046","11,029999733","LLC, LAL, BLL, HL, N","","");
INSERT INTO `vessel`  VALUES ( "384","?????","?.?. 142","HAL","","20,3500003815","14,8800001144","","5,4899997711","44,1100006104","?, ??, ?,???","","");
INSERT INTO `vessel`  VALUES ( "385","????????","?.?. 279","HAL","","3,3299999237","8,1999998093","","3,2000000477","11,0200004578","?, ??, ?,???","","");
INSERT INTO `vessel`  VALUES ( "386","????????","?.?. 193","HAL","","5,6900000572","9,3000001907","","3,7999999523","23,5200004578","?, ??, ?,?,???","","");
INSERT INTO `vessel`  VALUES ( "387","??????????","?.?. 161","HAL","","3,8299999237","9,1999998093","","3,7400000095","11,029999733","?, ???","","");
INSERT INTO `vessel`  VALUES ( "388","????????","?.?. 228","HAL","","8,9399995804","11,8500003815","1","4,0599999428","52,9199981689","LLC, LAL, BLL, HL, N","","");
INSERT INTO `vessel`  VALUES ( "389","???????","?.?. 113","HAL","","","9,1999998093","","3","63","?, ??, ?,?,???","","");
INSERT INTO `vessel`  VALUES ( "390","?????????","?.?. 172","HAL","","","8,5","","3,0999999046","11,0200004578","?, ??, ?,?,???","","");
INSERT INTO `vessel`  VALUES ( "391","??????","?.?. 1598","HAL","","10","12,25","1","4","37,4900016785","LLC, LAL, BLL, HL, N","","");
INSERT INTO `vessel`  VALUES ( "392","??????? ??????","?.?. 170","HAL","","5,3800001144","9,1000003815","","3,7999999523","32,3400001526","?, ??, ?,?","","");
INSERT INTO `vessel`  VALUES ( "393","????????","?.?. 1596","HAL","","14,9200000763","13,3999996185","1","4,75","106,5800018311","LLC, LAL, BLL, HL","","");
INSERT INTO `vessel`  VALUES ( "394","???","?.?. 282","HAL","","22,6700000763","13,6999998093","1","5,0999999046","73,5100021362","LLC, LAL, BLL, HL","","");
INSERT INTO `vessel`  VALUES ( "395","??. ????????","?.?. 92","HAL","","10,9200000763","12,1000003815","","4,25","69,8300018311","?, ??, ?,?,???","","");
INSERT INTO `vessel`  VALUES ( "396","??????","?.?. 1630","HAL","","11,470000267","11,470000267","","4,3299999237","89,6800003052","?, ??, ?,?,???","","");
INSERT INTO `vessel`  VALUES ( "397","?????????","?.?.191","HAL","","6,0399999619","9,5","","3,6500000954","11,029999733","?, ??, ?,?,???","","");
INSERT INTO `vessel`  VALUES ( "398","??. ????????","?.?. 13","HAL","","20,25","14,1300001144","","4,6700000763","110,2600021362","LAL, BLL, LLC,","","");
INSERT INTO `vessel`  VALUES ( "399","??. ????????","?.?. 910","HAL","","11,8299999237","12,3500003815","1","4,4600000381","121,2900009155","LAL, LLC, BLL, HL","","");
INSERT INTO `vessel`  VALUES ( "4","??????? ?","431","HAN","","10,5500001907","12,5","","3,4000000954","135","?,?,?,?","RD","VHF");
INSERT INTO `vessel`  VALUES ( "400","?????????","?.?. 64","HAL","","19,6700000763","14","","5","110,2699966431","?, ??, ?,???","","");
INSERT INTO `vessel`  VALUES ( "401","??????? ??????","?.?. 1236","HAL","","15,7899999619","13,5","","4,6999998093","110,2600021362","?, ??, ?,???","","");
INSERT INTO `vessel`  VALUES ( "402","??. ??????","?.?. 11","HAL","","10,9399995804","12,6999998093","1","4,8600001335","150,6999969482","LAL","","");
INSERT INTO `vessel`  VALUES ( "403","???. ????????","?.?. 340","HAL","","4,3099999428","8,6000003815","","3,0999999046","44,0999984741","??, ?,???","","");
INSERT INTO `vessel`  VALUES ( "404","????????? ?.","?.?. 1593","HAL","","15,3599996567","13,6000003815","1","4,5","91,9100036621","LAL, LLC, HL, BLL","","");
INSERT INTO `vessel`  VALUES ( "405","??. ????????","?.?. 159","HAL","","4,2600002289","9","","3,7999999523","11,029999733","?, ??, ?,???","","");
INSERT INTO `vessel`  VALUES ( "406","????????","?.?. 996","HAL","","16,2000007629","13,8000001907","","4,5","147,0200042725","LLC, LAL, BLL, HL","","");
INSERT INTO `vessel`  VALUES ( "407","???????-???????","?.?. 335","HAL","","3,5199999809","8,6000003815","1","3,4000000954","11,029999733","LAL,BLL, HL","","");
INSERT INTO `vessel`  VALUES ( "408","???????","?.?.?. 1876","HAL","","2,8299999237","7,8699998856","1","2,9000000954","62,8300018311","LLC, LAL, HL, BLL","","");
INSERT INTO `vessel`  VALUES ( "409","??. ??????","?.?. 1066","KAL","","","11,8000001907","1","","","","","");
INSERT INTO `vessel`  VALUES ( "410","???. ?????????","?.?. 519","KAL","","16,7000007629","11,8000001907","1","","110","","","");
INSERT INTO `vessel`  VALUES ( "413","??????? ?.","?.?. 78","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "414","??????","?.?. 104","KAL","","","17,3999996185","2","","220","","Son, Lor, R, AP","SSB");
INSERT INTO `vessel`  VALUES ( "415","???. ????????","?.?. 64","KAL","","","17","2","","400","","Lor, R","SSB");
INSERT INTO `vessel`  VALUES ( "417","??????? ?????????","?.?. 93","KAL","","","15,6999998093","2","","240","","R","");
INSERT INTO `vessel`  VALUES ( "418","?????????? ?.","?.?. 77","KAL","","","15,4499998093","2","","300","","R","");
INSERT INTO `vessel`  VALUES ( "420","?????????? ?.","?.?. 98","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "421","?????????? ?.","?.?. 91","KAL","","","17,8999996185","2","","286","","R, AP","SSB");
INSERT INTO `vessel`  VALUES ( "422","?????????","?.?. 72","KAL","","","15","2","","140","","R","SSB");
INSERT INTO `vessel`  VALUES ( "423","??????? ?????","?.?. 53","KAL","","","15","2","","178","","R","SSB");
INSERT INTO `vessel`  VALUES ( "426","??????","?.?. 135","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "427","?????? 2","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "428","2 ???????","?.?. 222","KAL","","","11,6999998093","1","","150","","R","");
INSERT INTO `vessel`  VALUES ( "429","?????-????????","?.?. 109","KAL","","","","","","","","R, AP, Sat","");
INSERT INTO `vessel`  VALUES ( "433","???? ?","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "434","??????? ???????","?.?. 215","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "436","??????","?.?. 224","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "437","8 ???????","?.?. 51","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "439","??????? 1","?.?. 139","HAN","","","13,1999998093","1","","150","","","");
INSERT INTO `vessel`  VALUES ( "440","?????","?.?. 409","HAN","","","13,1999998093","1","","150","","","");
INSERT INTO `vessel`  VALUES ( "441","??. ?????????","?.?. 121","HAN","","","13","1","","130","","","");
INSERT INTO `vessel`  VALUES ( "444","???????? ?.","?.?. 127","HAN","","","24,5799999237","3","","225","","","");
INSERT INTO `vessel`  VALUES ( "446","?????? ??","?.?. 149","CYC","","38,1800003052","14,9499998093","1","","150","","","");
INSERT INTO `vessel`  VALUES ( "447","????????","?.?. 997","CYC","","12,6059999466","12,5500001907","1","","95","","","");
INSERT INTO `vessel`  VALUES ( "448","???. ????????","?.?. 901","CYC","","24","14,8000001907","1","","140","","","");
INSERT INTO `vessel`  VALUES ( "449","??. ??????","?.?. 3743","CYC","","32","15","2","","120","","","");
INSERT INTO `vessel`  VALUES ( "45","?????????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "450","???? 2","?.?. 58","CYC","","16,2199993134","13","1","","135","","","");
INSERT INTO `vessel`  VALUES ( "451","?????1","?.?. 944","CYC","","23,2600002289","13,1999998093","1","","150","","","");
INSERT INTO `vessel`  VALUES ( "452","??????? 2","?.?.","CYC","","21,6599998474","13,5","1","","150","","","");
INSERT INTO `vessel`  VALUES ( "453","????????","?.?. 55","CRE","","10,8000001907","13","1","","150","","R, Son","");
INSERT INTO `vessel`  VALUES ( "454","??????","?.??.","OTH","","","11,3000001907","1","","50","","","");
INSERT INTO `vessel`  VALUES ( "455","???????","?.??. 332","OTH","","","16,8500003815","2","","185185","","","");
INSERT INTO `vessel`  VALUES ( "456","????????","?.??. 645","OTH","","","13","1","","175","","","");
INSERT INTO `vessel`  VALUES ( "457","???????","?.??. 296","OTH","","","18,4400005341","2","","360","","","");
INSERT INTO `vessel`  VALUES ( "458","?????","?.???. 03","OTH","","","9","","","5050","","","");
INSERT INTO `vessel`  VALUES ( "459","??. ????????","?.?????. 473","OTH","","","10,3000001907","1","","36","","","");
INSERT INTO `vessel`  VALUES ( "460","???????????","?.???. 13","OTH","","","16","2","","125150","","","");
INSERT INTO `vessel`  VALUES ( "461","??????? ?.","?.?????. 552","OTH","","","12","1","","120","","","");
INSERT INTO `vessel`  VALUES ( "462","????-????","?.?????. 995","OTH","","","8","","","72","","","");
INSERT INTO `vessel`  VALUES ( "463","?????????","?.?????. 556","OTH","","","14","1","","150","","","");
INSERT INTO `vessel`  VALUES ( "464","????? ?.","?.?????. 577","OTH","","","15","2","","150","","","");
INSERT INTO `vessel`  VALUES ( "465","??. ????????","?.?????. 489","OTH","","","9,5","","","60","","","");
INSERT INTO `vessel`  VALUES ( "466","????????","?.?????. 539","OTH","","","13,1000003815","1","","100","","","");
INSERT INTO `vessel`  VALUES ( "467","???????","?.?????. 569","OTH","","","10,6000003815","1","","120","","","");
INSERT INTO `vessel`  VALUES ( "468","??????","?.?????. 482","OTH","","","10,0399999619","1","","130","","","");
INSERT INTO `vessel`  VALUES ( "469","?????????","?.???. 25","OTH","","","8,1999998093","","","46","","","");
INSERT INTO `vessel`  VALUES ( "470","????????","?.???. 28","OTH","","","12,5","1","","140","","","");
INSERT INTO `vessel`  VALUES ( "471","????????","?.???. 27","OTH","","","8","","","46","","","");
INSERT INTO `vessel`  VALUES ( "472","?????????? ?.","?.????. 2","OTH","","","10,8199996948","1","","90","","","");
INSERT INTO `vessel`  VALUES ( "473","????????","?.????. 7","OTH","","","13","1","","115","","","");
INSERT INTO `vessel`  VALUES ( "474","??????????","?.?. 930","OTH","","","9,1999998093","","","75","","","");
INSERT INTO `vessel`  VALUES ( "475","????????","?.?. 964","OTH","","","9,5","","","75","","","");
INSERT INTO `vessel`  VALUES ( "476","?????????","?.?. 979","OTH","","","10","1","","75","","","");
INSERT INTO `vessel`  VALUES ( "477","??. ???????","?.?. 943","OTH","","","10,1000003815","1","","75","","","");
INSERT INTO `vessel`  VALUES ( "478","?????????","?.??. 284","OTH","","","14,1999998093","1","","240","","","");
INSERT INTO `vessel`  VALUES ( "479","??????","?.??. 267","OTH","","","14,5","1","","170","","","");
INSERT INTO `vessel`  VALUES ( "480","???? 2","?.??. 1207","OTH","","","9,1999998093","","","60","","","");
INSERT INTO `vessel`  VALUES ( "481","?????????","?.??. 1208","OTH","","","9,5","","","55","","","");
INSERT INTO `vessel`  VALUES ( "482","???????","?.???. 9","OTH","","","13,5","1","","135","","","");
INSERT INTO `vessel`  VALUES ( "483","????????","?.??. 1259","OTH","","","11,5","1","","75","","","");
INSERT INTO `vessel`  VALUES ( "484","??????????","?.??. 1181","OTH","","","12,5","1","","","","","");
INSERT INTO `vessel`  VALUES ( "485","???. ??????","?.?????. 387","OTH","","","10,5","1","","75","","","");
INSERT INTO `vessel`  VALUES ( "486","???. ???????","?.?????. 477","OTH","","","12,8000001907","1","","110","","","");
INSERT INTO `vessel`  VALUES ( "487","???????","?.?.???? 2","OTH","","","13,5","1","","120","","","");
INSERT INTO `vessel`  VALUES ( "488","?????","?.????. 11","OTH","","","10,0500001907","1","","200","","","");
INSERT INTO `vessel`  VALUES ( "489","?????? ?.","?.????. 693","OTH","","","8,3000001907","","","33","","","");
INSERT INTO `vessel`  VALUES ( "490","???. ?????????","?.????. 4194","OTH","","","12","1","","120","","","");
INSERT INTO `vessel`  VALUES ( "491","???. ??????","?.?????. 476","OTH","","","12,5","1","","120","","","");
INSERT INTO `vessel`  VALUES ( "492","???. ??????","?.????. 2075","OTH","","","13","1","","160","","","");
INSERT INTO `vessel`  VALUES ( "493","???. ??????????","?.???. 11","OTH","","","12,5","1","","75","","","");
INSERT INTO `vessel`  VALUES ( "494","???????","?. ????. 378","OTH","","","13,3000001907","1","","180","","","");
INSERT INTO `vessel`  VALUES ( "495","????????","?.????. 1888","OTH","","","14","1","","6060","","","");
INSERT INTO `vessel`  VALUES ( "496","????????","?.?. 4736","OTH","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "497","?????????","","OTH","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "498","????????","","OTH","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "499","??????-????","?.???. 1333","OTH","","","10,5","1","","130","","","");
INSERT INTO `vessel`  VALUES ( "5","????????","133","HAN","","33,7999992371","13,1999998093","","4,5999999046","238","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "500","??????","?.???. 35","OTH","","","17","2","","320","","","");
INSERT INTO `vessel`  VALUES ( "501","?????????? ?.","?.?. 504","OTH","","","16","2","","","","","");
INSERT INTO `vessel`  VALUES ( "502","?????????","?.?. 537","OTH","","","16","2","","240","","","");
INSERT INTO `vessel`  VALUES ( "503","??????","?.???. 36","OTH","","","16","2","","420","","","");
INSERT INTO `vessel`  VALUES ( "504","??????","?.?. 598","OTH","","","14,5","1","","160","","","");
INSERT INTO `vessel`  VALUES ( "505","?????????","?.?. 1068","OTH","","","14,1999998093","1","","100","","","");
INSERT INTO `vessel`  VALUES ( "506","????","?.???. 171","OTH","","","18","2","","320","","","");
INSERT INTO `vessel`  VALUES ( "507","??. ?????????????","?.?.586","OTH","","","14","1","","110","","","");
INSERT INTO `vessel`  VALUES ( "508","???????","?.?. 596","OTH","","","17","2","","296","","","");
INSERT INTO `vessel`  VALUES ( "509","????????","?.?.1445","OTH","","","9,6000003815","","","84","","","");
INSERT INTO `vessel`  VALUES ( "51","????? ?","?.?. 113","HAN","","44,5900001526","17,2000007629","","5,1399998665","150","?,?,?","RD,PX,LR","VHF,SSB");
INSERT INTO `vessel`  VALUES ( "510","???/??? ?.","?.?.569","OTH","","","16,75","2","","240","","","");
INSERT INTO `vessel`  VALUES ( "511","???/??? ?.","?.?. 585","OTH","","","17,5","2","","160","","","");
INSERT INTO `vessel`  VALUES ( "512","????????????","183","HAN","","26,6800003052","19,2999992371","2","","150","","","");
INSERT INTO `vessel`  VALUES ( "516","??. ?????????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "52","????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "530","?????? ?.","?.?. 523","KAL","","16,5900001526","14,1000003815","2","","180","","","");
INSERT INTO `vessel`  VALUES ( "549","??. ????????","?.?. 21","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "550","????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "551","??. ????????","?.?. 79","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "552","??????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "553","????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "554","??????????? 3","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "555","??. ??????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "556","???????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "557","??????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "558","??????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "559","??????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "560","?????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "561","????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "562","?????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "563","?????????-????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "564","??????? ?.","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "565","??????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "566","??????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "567","??. ????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "568","???????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "569","??????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "570","????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "571","????????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "572","?????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "574","???????","30075/239","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "575","??. ?????????","593/548","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "576","??. ????????","29745/450","","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "586","???????? ?.","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "587","?????????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "588","??. ????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "589","???????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "590","?????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "591","??????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "592","???????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "593","????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "594","????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "595","?????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "596","??. ?????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "598","?????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "6","?????????","126","HAN","","38,2999992371","14,9499998093","","4,6999998093","150","?,?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "60","??. ????","?.?. 550","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "600","???. ?????? 1","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "601","???. ?????? 2","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "605","????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "607","?????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "608","??. ??????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "610","?????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "613","???????? 2","?.?. 946","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "619","???. ?????? (??????)","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "620","???. ?????? (??????? ?????)","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "624","????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "625","?????? (??????)","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "626","??. ????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "627","???????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "628","???????? 1","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "629","???. ????????","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "630","???????? ??","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "632","???????? ??","","CYC","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "633","???. ???????","?.?. 274","CRE","","20","14","1","","","?,?","","");
INSERT INTO `vessel`  VALUES ( "634","???/???","?.?. 233","CRE","","4,5","11,6000003815","1","","125","?,??(???11???),??","GPS, Sonar","VHF");
INSERT INTO `vessel`  VALUES ( "635","?????????? ??","?.?. 577","CRE","","10,8900003433","12,5","1","","130","?, ?, ??","","");
INSERT INTO `vessel`  VALUES ( "640","???. ??????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "642","??. ?????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "643","????????????","?.?. 29","CRE","","16,1599998474","12","1","","74","???????, ?????","GPS, RADAR","VHF");
INSERT INTO `vessel`  VALUES ( "645","??????","?.?. 1431","OTH","","11,6800003052","12,3999996185","1","","70,5699996948","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "646","????????","?.?. 108","OTH","","10,4899997711","10,6000003815","1","","36,7599983215","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "647","????? ?????????","?.?. 50","OTH","","3,6400001049","9","","","36,0200004578","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "648","????? ????????","?.?. 116","OTH","","6,1599998474","10,220000267","1","","61,75","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "649","??????? ??????","?.?. 658","OTH","","12,279999733","12,3000001907","1","","93,3600006104","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "650","????? ????????","?.?. 80","OTH","","5,9699997902","10,220000267","1","","41,1599998474","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "651","????? ?????????-?????","?.?. 1420","OTH","","10,75","11,5","1","","94,0899963379","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "652","????????","?.?. 1650","OTH","","6,2300000191","10,5","1","","95,5599975586","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "653","????? ????????","?.?. 74","OTH","","10,6300001144","11,1999998093","1","","84,5400009155","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "654","????","?.?. 163","OTH","","1,2300000191","6,1999998093","","","11,029999733","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "655","??????","?.?. 1393","OTH","","7,2899999619","11,1000003815","1","","80,8600006104","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "656","???/???-?????","?.?. 6381","OTH","","4,4299998283","9","","","36,7599983215","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "657","????? ????????","?.?. 93","OTH","","1,9800000191","7,6999998093","","","7,3499999046","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "658","????? ????????","?.?. 66","OTH","","5,8600001335","10","1","","53,6599998474","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "659","????? ?????","?.?. 934","OTH","","9,3199996948","10,8999996185","1","","61","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "660","?????????","?.?. 176","OTH","","2,0999999046","7,5999999046","","","22,0499992371","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "661","??????-????????","?.?. 1379","OTH","","7,5900001526","10,8999996185","1","","38,2299995422","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "662","?????????????","?.?. 1389","OTH","","7,0799999237","10,3000001907","1","","41,1699981689","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "663","????? ????????","?.?. 137","OTH","","3,8900001049","8,6000003815","","","38","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "664","???/???","?.?. 25","OTH","","1,7799999714","7,3000001907","","","5,8800001144","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "665","????? ?????????","?.?. 234","OTH","","2,5599999428","8,1000003815","","","39,7000007629","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "666","????? ?????????","?.?. 21","OTH","","1,5700000525","7,0999999046","","","26,4599990845","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "667","????? ????????","?.?. 1438","OTH","","2,8900001049","8","","","88,2099990845","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "668","??????? ??","?.?. 1565","OTH","","4,5100002289","8,6000003815","","","27,5900001526","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "669","??????? ?????","?.?. 63","ALO","","4,0100002289","8,5","","","22,0499992371","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "670","?????????","?.?. 71","OTH","","3,0799999237","8,6000003815","","","22,0499992371","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "671","????????????","?.?. 1574","OTH","","22","15,8999996185","","","69,9800033569","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "672","???????","?.?. 96","OTH","","3,7300000191","8,8999996185","","","11,029999733","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "673","?????","?.?. 1619","OTH","","6,4299998283","9,8000001907","","","24,2600002289","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "674","???????","?.?. 1627","OTH","","4,3699998856","9,1999998093","","","33,8100013733","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "675","????? ????????","?.?. 118","OTH","","5,6900000572","10,3999996185","","","36,75","??,??,??,??,?","","");
INSERT INTO `vessel`  VALUES ( "676","?????????","?.?. 124","OTH","","3,7000000477","8,6999998093","","","36,7599983215","??,??,??,??,???","","");
INSERT INTO `vessel`  VALUES ( "677","?????????","?.?. 726","OTH","","4,2699999809","8,6999998093","","","11,029999733","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "678","????? ?????????","?.?. 43","OTH","","","","","","","??,??,??,??","","");
INSERT INTO `vessel`  VALUES ( "679","?????????","?.??. 1001","OTH","","","","","","","??,??,??,??,???","","");
INSERT INTO `vessel`  VALUES ( "680","?????","?.?. 387","OTH","","","","","","","??,??,??,??,?,???","","");
INSERT INTO `vessel`  VALUES ( "681","????????????","N.X. 183","HAN","","52","19,2999992371","2","5,3000001907","150","??,?,???,??","2GPS,A?,R,Son,??????","SSB,2VHF,Navtex,Sart");
INSERT INTO `vessel`  VALUES ( "682","????????? ?.","?.?. 7397","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "7","????????","430","HAN","","17,9400005341","12,6000003815","","4,3000001907","150","?,?,?,?","RD,PX,LR","VHF");
INSERT INTO `vessel`  VALUES ( "702","????????","","HAN","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "721","????????-????????","?.?. 279","HAL","","3,3299999237","8,1999998093","1","3,2000000477","11,0200004578","LLC, LAL, BLL, HL","","");
INSERT INTO `vessel`  VALUES ( "742","????? 1","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "743","?????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "744","???????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "745","??????? ???????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "746","???????????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "747","???????","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "748","????? 2","","ION","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "749","???. ???????","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "758","?????????","?.?. 496","HAN","","22","15,4499998093","2","4,6999998093","150","","","");
INSERT INTO `vessel`  VALUES ( "764","????","N.K. 226","KAL","","23,2099990845","14,3999996185","1","","120","","","");
INSERT INTO `vessel`  VALUES ( "769","????????? ?.","?.?. 212","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "774","????????","?.???. 1219","KAL","","9,3000001907","13,5","1","4,1999998093","30","BLL, N,","GPS Plotter, Radar, Sonar","VHF, ??????");
INSERT INTO `vessel`  VALUES ( "790","????????","?.?. 26","HAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "8","???????","?.?. 425","HAN","","25,0100002289","18,1499996185","","4,7199997902","220","?,?,?,??","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "805","????????????-?????","?.?. 34","ALO","","","","","","","LAL, BLL, N, HL","","");
INSERT INTO `vessel`  VALUES ( "806","????????","?.?. 124","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "807","?????????????","?.?. 139","ALO","","","","","","","BLL, N, HL","","");
INSERT INTO `vessel`  VALUES ( "808","?????????? ?????","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "810","??????? ?????????","?.?. 1447","HAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "811","????????","?.?. 1076","HAL","","","9,1999998093","1","","","","","");
INSERT INTO `vessel`  VALUES ( "812","??????????","?.?. 1094","HAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "813","???????","?.?. 1035","HAL","","","11,6499996185","1","","","","","");
INSERT INTO `vessel`  VALUES ( "814","??. ????????? ??","?.?. 959","HAL","","","9,3000001907","1","","","","","");
INSERT INTO `vessel`  VALUES ( "815","??????????? ??","?.?. 9","HAL","","","14,8999996185","1","","","","","");
INSERT INTO `vessel`  VALUES ( "836","????????????-?????","?.?. 560","KAL","","26","16,2999992371","2","","115","N, BLL, LLA","","");
INSERT INTO `vessel`  VALUES ( "855","????????","?.?. 190","CRE","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "876","????????","?.?. 617","HAN","","","11,2299995422","1","","48,125","LLC, N, BLL","Radar, Plotter","VHF");
INSERT INTO `vessel`  VALUES ( "879","??????? ???????","?.?. 606","HAN","","","10,6999998093","1","","100,5899963379","LLC","","");
INSERT INTO `vessel`  VALUES ( "883","????????????","","CYC","","","6","","","","","","");
INSERT INTO `vessel`  VALUES ( "897","V1","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "898","V2","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "899","V3","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "9","????????","?.?. 124","HAN","","33,7999992371","13,1999998093","","4,5999999046","144","?,?,?,?","RD,PX","VHF");
INSERT INTO `vessel`  VALUES ( "900","V4","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "901","V5","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "902","V6","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "903","V7","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "904","V8","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "905","V9","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "906","V10","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "907","V11","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "908","V12","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "909","V13","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "910","V14","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "911","V15","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "912","V16","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "913","V17","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "914","V18","","ALO","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "917","????????","?.?. 593","KAL","","18,8400001526","14","1","4,1999998093","70","LLA, TRP","","");
INSERT INTO `vessel`  VALUES ( "93","????????","?.?. 134","HAN","","","","","0","","","","");
INSERT INTO `vessel`  VALUES ( "930","????????? ?.","?.?. 106","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "932","???????","?.???. 67","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "933","??. ????????","?.?. 340","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "934","??. ?????????","?.?. 60","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "938","???. ?????","?.?. 90","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "939","Nikolaos Theodosios","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "941","??????","?.?. 63","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "942","Nikolaos San Lorentso","","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "945","???. ????????","?.?. 448","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "948","?????????? ?.","?.?. 55","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "955","??? ???????","?.?. 82","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "957","????","?.?. 8","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "959","??. ????????","?.?. 165","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "965","??????? ???????","?.?. 49","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "966","??. ???????","?.?. 98","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "971","?. ?????????","?.?. 176","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "973","????? ??????","?.?. 24","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "974","??????? ????????","?.?. 269","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "977","??. ????????","?.?. 76","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "978","???. ???????","?.?. 26","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "979","????","?.?. 42","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "980","??????? ???????","?.?. 37","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "981","??????????","?.?. 13","KAL","","","","","","","","","");
INSERT INTO `vessel`  VALUES ( "982","????????","?.?. 41","KAL","","","","","","","","","");


--
-- Tabel structure for table `vessel_expeditions`
--
DROP TABLE  IF EXISTS `vessel_expeditions`;
CREATE TABLE `vessel_expeditions` (
  `vexpedition_AMAS` varchar(45) CHARACTER SET greek DEFAULT NULL,
  `expedition_ID` int(11) NOT NULL,
  PRIMARY KEY (`expedition_ID`),
  UNIQUE KEY `expedition_ID_UNIQUE` (`expedition_ID`),
  KEY `AMAS_idx` (`vexpedition_AMAS`),
  CONSTRAINT `vexpedition_AMAS` FOREIGN KEY (`vexpedition_AMAS`) REFERENCES `vessel` (`AMAS`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `v_exp_id` FOREIGN KEY (`expedition_ID`) REFERENCES `expedition` (`expedition_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
